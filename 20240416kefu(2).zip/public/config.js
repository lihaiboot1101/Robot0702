/*window.Glod = {
BaseUrl:"http://xxx.api.com", // 你的接口路径(这里是window对象)
.......
}
webpack打包vue项目后，配置可以修改的配置文件
https://www.cnblogs.com/xiaolucky/p/12929720.html

使用
https://www.freesion.com/article/28231429547/
*/
const Glod = {
	"weliveApi" : "http://39.105.5.113:3080",
	"weliveWS" : "ws://39.105.5.113:8620",
	"api": "http://39.105.5.113:1040/xf-engine/",//后端交互接口
	"API_MS" : "http://39.105.5.113:1030/xf-ms",//文档下载服务器配置
	"browserTitle": "智能客服",//页面title
	"sysName": "校园智能客服",//系统名称
	"hasPraise": true, // 是否配置点赞功能
	"hasTime": false, // 是否需要显示时间
	"accessToken": "6bc2197cbdc7a334331f464819e7f375",
	"channel_id": "80000",
	//"authLogin": "http://pass.sdctcm.edu.cn/tpass/login?service=http://39.105.5.113:1040/xf-engine/",
	// "authLogout": "http://pass.sdctcm.edu.cn/tpass/logout?service=http://39.105.5.113:1040/xf-engine/",
	"schoolHomeUrl": "http://pass.sdctcm.edu.cn", // 8.由于便捷入口功能暂未定，先改为图片，图片上增加超链接到学校首页
	"imagePath": "http://39.105.5.113:1030/xf-ms/views/images/", //界面配置图片加载资源路径
	"hsaLogin" : false,
	"hsaLive" : true,   // 在线客服
	"openSatisfaction" : false,   // 开启满意度
	"quickList" : [
		{
			"img" : "img/menu-1.png",
			"name" : "网络报修",
			"toUrl" : "http://www.baidu.com"
		},{
			"img" : "img/menu-2.png",
			"name" : "后勤报修",
			"toUrl" : "http://www.baidu.com"
		},{
			"img" : "img/menu-3.png",
			"name" : "我要留言",
			"toUrl" : "http://39.105.5.113:1030/xf-ms/user/free/userLogin?user_login_name=admin&user_password=634965e351e5b74e76d0d8322bf43600&user_email=/xf-ms/views/sys_manage/leave_message.html"
		},{
			"img" : "img/menu-4.png",
			"name" : "校车安排",
			"toUrl" : "http://www.baidu.com"
		},{
			"img" : "img/menu-5.png",
			"name" : "电话查询",
			"toUrl" : "http://www.baidu.com"
		},{
			"img" : "img/menu-6.png",
			"name" : "虚拟卡领取",
			"toUrl" : "http://www.baidu.com"
		}
	],
	// 轮播图
	"slides" : [
		"img/banner-1.png",
		"img/banner-1.png"
	],
}
