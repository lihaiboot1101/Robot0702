//封装post，get,patch 请求
import { request } from "./servies";
 const jyRquest={
    //  post 封装请求
    post(config){
     return request({...config,method:'POST'})
    },
	postJSON(url, params){
	 return this.post({
		 url: url,
		 data: params,
		 headers: {
		       'Content-Type': 'application/json'
		 }
	 })
	},
    get(config){
        return request({...config,method:'GET'})
    },
    patch(config){
    return request({...config,method:'PATCH'})
       }
}
export default jyRquest