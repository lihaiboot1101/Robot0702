
/* WeLive guest.js  @Copyright bjxdwy.com */

//弹出消息
function popInfo(info, sec){
	if(sec){
		layer.msg(info, {time: sec * 1000});
	}else{
		layer.msg(info);
	}
}

//显示大图片
function showImage(me, width, height){
	var popup = $("#welive_big_img");

	var new_w = 1, new_h = 1, new_top = 0, new_left = 0;

	if(window_height < 1) window_height = 1;

	if(width/height >= window_width/window_height){
		new_w = width;
		if(new_w > window_width) new_w = window_width - 30;
		new_h = height * new_w / width;
	}else{
		new_h = height;
		if(new_h > window_height) new_h = window_height - 30;
		new_w = width * new_h / height;
	}

	new_w = parseInt(new_w);
	new_h = parseInt(new_h);

	new_left = parseInt((window_width - new_w)/2);
	new_top = parseInt((window_height - new_h)/2);

	//点击或者触控弹出层外的半透明遮罩层, 关闭弹出层
	popup.bind("click",  function(e) {
		popup.hide();
		$(this).unbind("click");
	});

	popup.children('.big_img_wrap').css({top: new_top, left: new_left, width: new_w, height: new_h}).html('<img src="' + me.src + '" style="width: ' + new_w + 'px;height: ' + new_h + 'px;">');
	popup.fadeIn(200);
}

//根据select设置对象显示title
function showTitle(select){
	function showTT(e){
		$("#welive_div_toop").css({"top": (e.pageY + 20) + "px","position": "absolute","left": (e.pageX + 12) + "px"}).show("fast");
	}

	$(select).mouseover(function (e) {
		if(!this.title) return;
		this.Mytitle = this.title;
		this.title = "";
		$("body").append("<div id='welive_div_toop' style='border: 1px solid #000;background:#ffff00;padding:2px 5px;'>" + this.Mytitle + "</div>");
		showTT(e);
	}).mouseout(function () {
		if(!this.Mytitle) return;
		this.title = this.Mytitle;
		$("#welive_div_toop").remove();
	}).mousemove(function (e) {
		showTT(e);
	});
}

//JQ闪动特效  ele: JQ要闪动的对象; cls: 闪动的类(className); times: 闪动次数
function eleShake(ele, cls, times){
	var i = 0, t = false, o = ele.attr("class")+" ", c = "", times = times||3;
	if(t) return;
	t= setInterval(function(){
		i++;
		c = i%2 ? o+cls : o;
		ele.attr("class",c);
		if(i==2*times){
			clearInterval(t);
			ele.removeClass(cls);
		}
	},200);
}

//滚动到底部
function scrollBottom(){
	historier.scrollTop(20000); //滚动到底部
}

//Ajax封装
var ajax_isOk = 1;
function ajax(url, send_data, callback) {
	if(!ajax_isOk) return false;
	$.ajax({
		url: url,
		data: send_data,
		type: "post",
		cache: false,
		dataType: "json",
		beforeSend: function(){ajax_isOk = 0;},
		complete: function(){ajax_isOk = 1;},
		success: function(data){
			if(callback)	callback(data);
		},
		error: function(XHR, Status, Error) {
			welive.status = 1;
			file_temp_data = "";
			popInfo('ajax error', 8);
		}
	});
}

//设置cookie
function setCookie(n,val,d) {
	var e = "";
	if(d) {
		var dt = new Date();
		dt.setTime(dt.getTime() + parseInt(d)*24*60*60*1000);
		e = "; expires="+dt.toGMTString();
	}
	document.cookie = n+"="+val+e+"; path=/";
}

//获取cookie
function getCookie(n) {
	var a = document.cookie.match(new RegExp("(^| )" + n + "=([^;]*)(;|$)"));
	if (a != null) return a[2];
	return '';
}

//将json数据转换成json对象
function parseJSON(data) {
	if(window.JSON && window.JSON.parse) return window.JSON.parse(data);
	if(data === null) return data;
	if(typeof data === "string") {
		data = $.trim(data);
		if(data) {
			var rvalidchars = /^[\],:{}\s]*$/,
				rvalidbraces = /(?:^|:|,)(?:\s*\[)+/g,
				rvalidescape = /\\(?:["\\\/bfnrt]|u[\da-fA-F]{4})/g,
				rvalidtokens = /"[^"\\\r\n]*"|true|false|null|-?(?:\d+\.|)\d+(?:[eE][+-]?\d+|)/g;

			if(rvalidchars.test(data.replace(rvalidescape, "@").replace(rvalidtokens, "]").replace(rvalidbraces, ""))) {
				return (new Function("return " + data))();
			}
		}
	}
	return false;
}

//新消息闪动页面标题
function flashTitle() {
	clearInterval(ttt_3);
	flashtitle_step=1;
	ttt_3 = setInterval(function(){
		if (flashtitle_step==1) {
			welive_cprt.addClass("hover");
			document.title='【' + langs.msg + '】'+pagetitle;
			flashtitle_step=2;
		}else{
			welive_cprt.removeClass("hover");
			document.title='【　　　】'+pagetitle;
			flashtitle_step=1;
		}
	}, 500);
}

//停止闪动页面标题
function stopFlashTitle() {
	if(flashtitle_step != 0){
		flashtitle_step=0;
		clearInterval(ttt_3);
		welive_cprt.removeClass("hover");
		document.title=pagetitle;

		if(welive.unread){
			welive.unread = 0;
			new_info.fadeOut(800);

			if(welive.status && !welive.isRobot) weliveSend({type: "g_readed"}); //发送已读信号
		}
	}
}

//获得计算机当前时间
function getLocalTime() {
	var date = new Date();

	function addZeros(value, len) {
		var i;
		value = "" + value;
		if (value.length < len) {
			for (i=0; i<(len-value.length); i++)
				value = "0" + value;
		}
		return value;
	}
	return addZeros(date.getHours(), 2) + ':' + addZeros(date.getMinutes(), 2) + ':' + addZeros(date.getSeconds(), 2);
}

//格式化输出信息
function formatOutput(data) {
	//生成URL链接
	data = data.replace(/((((https?|ftp):\/\/)|www\.)([\w\-]+\.)+[\w\.\/=\?%\-&~\':+!#;]*)/ig, function($1){return getURL($1);});
	//将表情代码换成图标路径
	data = data.replace(/\[:(\d*):\]/g, '<img src="' + SYSDIR + 'public/smilies/$1.png">').replace(/\\n/g, '<br>').replace(/\n/g, '<br>');
	return data;
}

//格式化生成URL
function getURL(url, limit) {
	if(!limit) limit = 60;
	var urllink = '<a href="' + (url.substr(0, 4).toLowerCase() == 'www.' ? 'http://' + url : url) + '" target="_blank" title="' + url + '">';
	if(url.length > limit) {
		url = url.substr(0, 30) + ' ... ' + url.substr(url.length - 18);
	}
	urllink += url + '</a>';
	return urllink;
}

//插入表情符号
function insertSmilie(code) {
	code = '[:' + code + ':]';
	var obj = msger[0];

	var selection = document.selection;
	obj.focus();

	if(typeof obj.selectionStart != 'undefined') {
		var opn = obj.selectionStart + 0;
		obj.value = obj.value.substr(0, obj.selectionStart) + code + obj.value.substr(obj.selectionEnd);
	} else if(selection && selection.createRange) {
		var sel = selection.createRange();
		sel.text = code;
		sel.moveStart('character', -code.length);
	} else {
		obj.value += code;
	}
}

//设置为默认头像
function setDefaultAvatar(){
	welive_op.find("#welive_avatar").attr("src", SYSDIR + "public/img/welive.png");
	welive_op.find("#welive_name").html(langs.welive);
	welive_op.find("#welive_duty").html(langs.notready);
}

//socket连接
function weliveLink(){
	welive.ws = new WebSocket(WS_HEAD + WS_HOST + ':'+ WS_PORT);

	welive.ws.onopen = function(){
		welive.linked = 1; //websocket连接成功
		welive.closeQuiet = 1; //连接成功后, websocket连接断开时不显示: 连接失败，请稍后重试
		setTimeout(function(){weliveVerify();}, 100); //连接成功后, 小延时再验证用户, 否则IE下刷新时发送数据失败
	};

	welive.ws.onclose = function(){weliveClose();};
	welive.ws.onmessage = function(get){weliveParseOut(get);};
}


//记住访客id, 上传session会话
function rememberGuest(gid, sess){
	gid = parseInt(gid);

	if(!guest.gid || guest.gid != gid){
		guest.gid = gid; //更新ID号
		setCookie(COOKIE_USER, gid, 3650); //写cookie
	}

	//产生一个session会话记录, 用于验证上传图片等, 以免产生非法操作
	guest.sess = sess; //解决safari禁止第三方cookie的问题
	setCookie(COOKIE_USER + "_sess", sess, 0); //随进程消失, 上传文件等时首先验证
}


//输出聊天记录
function outputRecords(reArr){
	var recs = '';
	$.each(reArr, function(i, rec){
		if(rec.ft == 1){//上传图片记录
			var img_arr = rec.m.split("|");
			var img_w = parseInt(img_arr[1]);
			var img_h = parseInt(img_arr[2]);

			if(img_w < 1) img_w = 1;
			var new_h = parseInt(img_h * 250 / img_w); //CSS样式中已确定宽度为250

			var rec_i = '<div class="sending_div" style="height:' + new_h + 'px;"><img src="' + SYSDIR + "upload/img/" + img_arr[0] + '" class="sending_img" onclick="showImage(this, ' + img_w + ', ' + img_h + ');"></div>';

		}else if(rec.ft == 2){ //上传的文件记录
			var file_arr = rec.m.split("|");

			if(rec.t == 1){ //客服的
				var rec_i = '<a href="' + SYSDIR + 'upload/file/' + file_arr[0] + '" target="_blank" download="' + file_arr[1] + '" class="down"><img src="' + SYSDIR + 'public/img/save.png">&nbsp;&nbsp;' + langs.click_download +  file_arr[1] + '</a>';
			}else{
				//自己发送的文件不提供下载, 减少资源消耗
				var rec_i = file_arr[1] + "<br>... " + langs.upload_done;
			}
		}else if(rec.ft == 3){ //短语音
			var file_arr = rec.m.split("|");

			if(rec.t == 1){ //客服的
				var classN = "voice_left";
			}else{
				var classN = "voice_right";
			}

			var rec_i = '<div class="' + classN + '" src="' + SYSDIR + 'upload/file/' + file_arr[0] + '" onclick="playVoice(this);"><span class="sec">' + file_arr[1] + '"</span><span class="voice_icon"></span></div>';
		}else{
			var rec_i = formatOutput(rec.m);
		}

		if(rec.t == 1){ //客服的
			if(rec.fid == guest.aid){
				var welive_duty_i = welive_duty;
			}else{
				var welive_duty_i = langs.welive;
			}

			recs += '<div class="msg l"><div class="a">' +  rec.f + ' - ' + welive_duty_i + '<i>' + rec.d + '</i></div><b></b><div class="b"><div class="i">' + rec_i + '</div></div></div>';

		}else{ //自己的

			recs += '<div class="msg r"><b></b><div class="b"><div class="i">' + rec_i + '</div></div><i>' + rec.d + '</i></div>';
		}
	});

	if(recs != '') {
		recs += '<div class="msg s"><div class="b"><div class="i">' + langs.records + '</div></div></div>';
		historier.append(recs); //输出
		scrollBottom(); //滚动到底部
	}
}


//解析数据并输出
function weliveParseOut(get){
	var d = false, type = 0, raw = 0, data = parseJSON(get.data);
	if(!data) return; //没有数据返回

	switch(data.x){

		case 5: //客人与客服文字对话
			if(data.a == 1){ //客服发来的
				welive.flashTitle = 1;
				type = 1; d = data.i;

				//机器人工作时
				if(welive.isRobot){
					setTimeout(function(){
						historier.find("s.un").html(langs.readed).removeClass("un"); //已读
						welive.status = 1; //机器人回复输出后才能发送第二条

						if(typeof data.av != 'undefined' && data.av != ''){
							clearTimeout(ttt_5);
							toggleAvatar(data.av); //变换头像

							ttt_5 = setTimeout(function() {
								welive_op.find("#welive_avatar").attr("src", SYSDIR + "avatar/robot/0.png");
							}, 30000); //30秒后头像恢复
						}

						historier.children(".robot_typing").remove(); //清除机器人思考标志
						weliveOutput(d, type, raw); //输出

					}, 1000); //信息延迟显示

					return;
				}
			}else{ //自己发出的对话
				type = 2; 
				if(!welive.isRobot) welive.status = 1; //发送完成允许发送第二条信息

				d = welive.msg.replace(/</g, "&lt;").replace(/>/g, "&gt;"); //防止自己发js代码时发生显示错误
				welive.msg = ''; //清空临时信息

				sender.removeClass('loading2');
			}

			break;

		case 8: //人工客服发来的标记已读信息

			historier.find("s.un").html(langs.readed).removeClass("un");
			return true;

			break;

		case 6: //客人特别操作或返回信息
			switch(data.a){

				case 8: //客人登录成功
					welive.status = 1; //允许发信息
					welive.autolink = 6; //允许自动重连6次

					welive.isRobot = parseInt(data.irb); //系统是否为无人值守状态

					guest.fn = data.fn; //客人姓名
					guest.aid = parseInt(data.aid); //更新客服的id, 重新连接时用
					guest.an = data.an; //客服姓名
					guest.au = parseInt(data.au); //上传授权, 强制转成数字1或0, 方便判断, JS里if("0") 是true, php里为false

					 //更新头像及身份
					welive_name = data.an;
					welive_duty = data.p;
					welive_op.find("#welive_avatar").attr("src", SYSDIR + "avatar/" + data.av);
					welive_op.find("#welive_name").html(welive_name);
					welive_op.find("#welive_duty").html(welive_duty);

					historier.removeClass('loading3'); //去掉loading样式

					msger.focus();
					welive.flashTitle = 1;
					type = 8; d = welcome;
					raw = 1; //原生的, 不解析html

					outputRecords(data.re); //输出对话记录

					rememberGuest(data.gid, data.sess); //记住访客id, 上传session会话

					autoOffline(); //启动自动离线

					if(welive.isRobot) {
						$("#toolbar_transto").show();
						$("#toolbar_voice").hide();
					}else{
						welive.temp = '';
						weliveRuntime(); //非机器人服务时, 启动实时输入状态
						$("#toolbar_transto").hide();
						$("#toolbar_voice").show();
					}

					//启动心跳, 即每隔26秒自动发送一个特殊信息, 解决IE下30秒自动断线的问题
					//设置一个怪异的数字避免与自动离线的时间间隔重合, 避免在同一时间点上send数据时, 可能产生-----幽灵bug
					ttt_1 = setInterval(function() {
						weliveSend({type: "ping"});
					}, 26125);

					break;

				case 1: //客服重新上线
					clearTimeout(welive.ttt2); //清除客服离线时自动转接

					setTwoStatus(1); //状态正常, 允许重连
					welive.flashTitle = 1;
					type = 3; d = welive_name + langs.aback;

					break;

				case 2: //客服离线
					welive.status = 0;
					welive.flashTitle = 1;
					type = 4; d = welive_name + langs.offline;

					//1分钟后发送请求重新分配客服的请求
					welive.ttt2 = setTimeout(function(){
						weliveSend({type: "g_handle", operate: "redistribute"});
					}, 59973);

					break;

				case 4: //重复连接
				case 5: //自动离线
					type = 4;
					setTwoStatus(0); //状态未正常, 不允许重连
					setDefaultAvatar(); //设为初始头像
					d = (data.a == 4 ? langs.relinked : langs.autooff) + '<br><a onclick="weliveLink();$(this).parents(\'.msg\').hide();return false;" class="relink">' + langs.rebtn + '</a>';

					break;

				case 6: //被踢出
					setTwoStatus(0);
					setDefaultAvatar(); //设为初始头像
					type = 4; d = langs.kickout;

					break;

				case 7: //被禁言
					setTwoStatus(0);

					welive.flashTitle = 1;
					type = 4; d = langs.banned;

					break;

				case 9: //无客服在线 或 客服组不存在或关闭时 或 禁言中
					setTwoStatus(0);
					type = 4;
					d = langs.nosuppert; //客服不在线

					if(data.i == "nogroup"){
						d = langs.team_off; //客服组不存在或关闭
					}else if(data.i == "banned"){
						d = langs.banned; //禁言中
					}

					setDefaultAvatar(); //设为初始头像

					break;

				case 11: //被转接
					setTwoStatus(1);

					if(welive.isRobot) clearTimeout(ttt_5); //转接前是机器人服务时, 阻止机器人头像延迟变换
					welive.isRobot = parseInt(data.irb); //系统是否为无人值守状态

					guest.aid = data.aid; //更新客服的id, 重新连接时用
					guest.an = data.an; //客服姓名
					guest.au = parseInt(data.au); //上传权限

					 //更新头像及身份
					welive_name = data.an;
					welive_duty = data.p;

					welive_op.find("#welive_avatar").attr("src", SYSDIR + "avatar/" + data.av);
					welive_op.find("#welive_name").html(welive_name);
					welive_op.find("#welive_duty").html(welive_duty);

					 //机器人服务时, 转人工服务按钮状态等
					if(welive.isRobot) {
						clearInterval(ttt_6); //清除提交实时输入状态
						$("#toolbar_transto").show();
						$("#toolbar_voice").hide();
					}else{
						welive.temp = '';
						weliveRuntime(); //启动实时输入状态
						$("#toolbar_transto").hide();
						$("#toolbar_voice").show();
					}

					msger.focus();
					welive.flashTitle = 1;
					type = 4; d = langs.transfer + data.an;

					break;

				case 14: //评价返回
					msger.focus();

					if(data.s == "1"){
						welive.flashTitle = 1;
						type = 1; d = '<font color=red>' + langs.rating_thanks + '</font>[:16:]';
					}else{
						popInfo(langs.rating_limit, 6);
						return false;
					}

					break;

				case 15: //请求转人工客服 返回

					welive.status = 1;
					msger.focus();

					if(data.s == "2"){
						popInfo(langs.trans_to_failed, 4);
					}

					return true;

					break;
			}

			break;

		case 7: //上传图片等
			switch(data.a){

				case 1: //客服授权上传
				    if(!allow_uploadfile || (allow_uploadfile && !auth_upload)) return false; //屏蔽客服授权信息

					guest.au = 1;
					msger.focus();
					welive.flashTitle = 1;
					type = 3; d = langs.got_upload_auth;

					break;

				case 2: //客人上传图片通知客服后返回的信息--表示上传成功

					//进度条消失(指最后一个上传图片的进度条)
					sending_mask.remove();

					welive.status = 1; //允许发送信息
					msger.focus();

					break;

				case 4: //客服发来的图片

					type = 1; //客服发来的
					welive.flashTitle = 1; //声音
					raw = 1; //原生的

					if(data.w <1) data.w = 1;
					var img_h = parseInt(data.h * 250 / data.w); //CSS样式中已确定宽度为250

					d = '<div class="sending_div" style="height:' + img_h + 'px;"><img src="' + SYSDIR + 'upload/img/' + data.i + '" class="sending_img" onclick="showImage(this, ' + data.w + ', ' + data.h + ');"></div>';

					break;

				case 5: //客人上传文件通知客服后返回的信息--表示上传成功

					//进度条消失(指最后一个上传文件的进度条)
					historier.find(".uploading_info:last").html("... " + langs.upload_done).css({"color":"blue", "font-weight":"bold"});

					//sending_mask.remove();
					historier.find(".uploading_mask:last").parent().fadeOut(1000, function(){
						$(this).remove();					
					});

					welive.status = 1; //允许发送信息
					msger.focus();

					break;

				case 6: //客服上传文件
					type = 1; //客服发来的
					welive.flashTitle = 1; //声音
					raw = 1; //原生的

					d = '<a href="' + SYSDIR + 'upload/file/' + data.i + '" target="_blank" download="' + data.o + '" class="down"><img src="' + SYSDIR + 'public/img/save.png">&nbsp;&nbsp;'  + langs.click_download +  data.o + '</a>';

					break;

				case 7: //客服发来的短语音
					type = 1; //客服发来的
					welive.flashTitle = 1; //声音
					raw = 1; //原生的

					var d = '<div class="voice_left" src="' + SYSDIR + 'upload/file/' + data.i + '" onclick="playVoice(this);"><span class="sec">' + data.s + '"</span><span class="voice_icon"></span></div>';

					break;

				case 8: //自己发送语音返回
					welive.status = 1; //允许再录音

					if(data.i == "err"){
						historier.find(".voice_right:last").parents(".msg.r").remove(); //删除最后的语音信息
						popInfo(langs.err_sendvocie, 5);
					}

					break;

				case 9: //客服撤回一条消息

					type = 3; d = langs.draw_back;
					historier.find(".msg.l:last").remove();

					break;
			}

			break;
	}

	weliveOutput(d, type, raw); //输出
}

//交流输出信息, raw为true时不解析html
function weliveOutput(d, type, raw){
	if(d === false || !type) return; //没有信息及类型返回

	if(welive.flashTitle){
		flashTitle();
		if(welive.sound) sounder.html(welive.mp3); //发声音
		welive.flashTitle = 0;
	}

	switch(type){
		case 1: //客服
		case 8: //问候语, 信息不解析(支持html), 不计数
			if(!welive.isRobot && type == 1){
				welive.unread += 1; //有未读信息
				new_info.html(welive.unread).show();
			}

			d = '<div class="msg l"><div class="a">' + welive_name + ' - ' + welive_duty + '<i>' + getLocalTime() + '</i></div><b></b><div class="b"><div class="i">' + (raw ? d : formatOutput(d)) + '</div></div></div>';
			break;
		case 2: //客人
			d = '<div class="msg r"><b></b><div class="b"><div class="i">' + (raw ? d : formatOutput(d)) + '</div></div><i>' + getLocalTime() + '<br><s class="un">' + langs.unread + '</s></i></div>';
			break;
		case 3: //正常提示
			d = '<div class="msg s"><div class="b"><div class="i">' + d + '</div></div></div>';
			break;
		case 4: //错误提示
			d = '<div class="msg e"><div class="b"><div class="i">' + d + '</div></div></div>';
			break;
	}

	historier.append(d);

	//机器人工作时, 访客发送的信息显示后, 添加机器思考标志
	if(type == 2 && welive.isRobot){
		historier.children(".robot_typing").remove();
		d = '<div class="msg l robot_typing"><div class="a">' + welive_name + ' - ' + welive_duty + '<i></i></div><b></b><div class="b"><div class="i"></div></div></div>';
		historier.append(d);
	}

	scrollBottom(); //滚动到底部
}

//设置welive的两个状态
function setTwoStatus(option){
	if(option){
		welive.status = 1; //状态正常, 可以送消息
		welive.autolink = 1; //允许重连
	}else{
		welive.status = 0;
		welive.autolink = 0;
	}
}

//变换头像
function toggleAvatar(av) {
	history_wrap.append('<div class="animate_avatar"><img src="' + SYSDIR + "avatar/" + av + '"></div>');
	$(".animate_avatar").animate({left:0, bottom: (history_wrap.height() + 120) + "px"}, 300, "", function(){
		$(this).remove();
		welive_op.find("#welive_avatar").attr("src", SYSDIR + "avatar/" + av);
	});
}

//访客连接验证
function weliveVerify(){
	weliveSend({type: "login", from: "front", gid: guest.gid, grid: guest.grid, oid: guest.oid, fn: guest.fn, au: guest.au, aid: guest.aid, lang: guest.lang, key: SYSKEY, code: SYSCODE, fromurl: guest.fromurl, agent: guest.agent, mobile: 0});
}

//连接断开时执行
function weliveClose(){
	welive.linked = 0; //标记连接失败
	clearTimer(); //清理定时器

	//允许重连时
	if(welive.autolink > 0){
		welive.closeQuiet = 0;
		welive.autolink -= 1;
		weliveOutput(langs.relink, 3);
		setTimeout(function(){weliveLink();}, 6000); //6秒后自动重连
		return false;
	}

	//不允许重连时
	historier.removeClass('loading3');
	if(welive.closeQuiet){
		welive.closeQuiet = 0;
	}else{
		weliveOutput(langs.failed, 4);
	}
}

//离开页面或断线时清理定时器
function clearTimer(){
	welive.status=0;
	clearTimeout(welive.ttt); //自动离线
	clearTimeout(welive.ttt2); //客服离线时自动转接
	clearInterval(ttt_1); //发送心跳数据
	clearInterval(ttt_2); //上传进度条
	clearInterval(ttt_3); //标题闪烁
	clearInterval(ttt_6); //实时输入状态
}

//发送信息(直接)
function weliveSend(d){
	var re = 0;

	if(welive.linked){
		re = 1;
		welive.ws.send(JSON.stringify(d)); //将json对象转换成字符串发送
	}else{
		popInfo(langs.notready);
	}

	return re; //回返是否成功
}

//发送输入框文本
function weliveSendMsg(){
	if(welive.status) {
		var msg = $.trim(msger.val());

		if(msg){
			if(msg.length > 2048){
				popInfo(langs.msg_too_long);
				return false;
			}

			welive.temp = ''; //终止实时输入提交数据
			sender.addClass('loading2');
			welive.msg = msg; //先记录客人的发言

			msg = {type: "msg", sendto: "back", msg: msg};
			if(!weliveSend(msg)) return false;

			welive.status = 0; //发送后，改变状态避免未完成时发送第二条信息
			autoOffline(); //信息发送完成后, 自动离线计时开始
		}else{
			popInfo(langs.notinput);
		}

		msger.val('');
	}else{
		popInfo(langs.notready);
	}

	msger.focus(); //输入框焦点
}

//自动离线
function autoOffline(){
	if(!welive.linked) return; //未连接不自动离线
	if(welive.ttt) clearTimeout(welive.ttt); //清除自动离线

	welive.ttt = setTimeout(function(){
		weliveSend({type: "g_handle", operate: "offline"});
	}, offline_time);
}

//启动输入状态更新
function weliveRuntime(){
	ttt_6 = setInterval(function(){
		if(welive.status) {
			var msg = $.trim(msger.val());

			if(msg && msg != welive.temp){

				weliveSend({type: "runtime", msg: msg});
				welive.temp = msg; //记录正在输入的信息

			//清空输入框后, 给客服发通知, 去掉输入状态
			}else if(!msg && welive.temp){

				weliveSend({type: "runtime", msg: ""});
				welive.temp = '';
			}
		}

	}, update_time);
}

//验证上传文件权限
function checkUploadAuth(){
	if(welive.isRobot || !allow_uploadfile){
		popInfo(langs.no_upload_robot);
		return false;
	}else if(!guest.au && auth_upload){
		popInfo(langs.no_upload_auth);
		return false;
	}

	return true;
}

//读取图片文件
function readImageFile(file, obj){
	var reader = new FileReader();
	reader.onload = function(e) {
		var img = new Image();
		img.src = reader.result;

		img.onload = function() {
			var w = img.width,
				h = img.height;

			if(file.type.toLowerCase() == 'image/gif'){

				var base64 = e.target.result; //可保持gif动画效果

			}else{

				var canvas = document.createElement('canvas');

				var ctx = canvas.getContext('2d');
				$(canvas).attr({width: w,	height: h});
				ctx.drawImage(img, 0, 0, w, h);

				var base64 = canvas.toDataURL(file.type, 0.6); //canvas对JPG图片有压缩效果, gif, png
			}

			var result = {
				url: window.URL.createObjectURL(file),
				w: w,
				h: h,
				size: file.size,
				type: file.type,
				base64: base64.substr(base64.indexOf(',') + 1),
			};

			weliveSendImage(result);
		};

		img.onerror = function() {
			$(obj).val("");
			popInfo(langs.img_badtype);
		};
	};

	reader.readAsDataURL(file);
}

//传送图片, data对象属性: size文件大小(字节), type(文件类型), base64(图片纯净的base64代码)
function weliveSendImage(data){
	$("#upload_img").val("");

	//验证上传图片权限
	if(welive.isRobot) return;

	//限定文件大小及类型(限约10M)
	if(data.size > 10240000){
		popInfo(langs.img_limit);
		return;
	}
	// 文件超出了限制
	if($.inArray(data.type.toLowerCase(), ["image/jpg","image/jpeg","image/png","image/gif"]) < 0) {
		popInfo(langs.img_badtype);
		return;
	}

	if(welive.status && welive.linked) {

		welive.status = 0; //图片上传时不允许发送信息

		var sending_img_w = data.w; //图片的宽度
		var sending_img_h = data.h; //图片的高度

		if(sending_img_w < 1) sending_img_w = 1;
		sending_mask_h = parseInt(sending_img_h * 250 / sending_img_w); //CSS样式中已确定宽度为250

		var img_str = '<div class="sending_div" style="height:' + sending_mask_h + 'px;"><img src="' + data.url + '" class="sending_img" onclick="showImage(this, ' + data.w + ', ' + data.h + ');"><div class="sending_mask" style="line-height:' + sending_mask_h + 'px;height:' + sending_mask_h + 'px;">' + langs.uploading + '</div></div>';

		weliveOutput(img_str, 2, 1); //原生

		//显示上传进度
		sending_mask = historier.find(".sending_mask:last"); //仅处理最后一次上传的图片, jq1.2.6不支持last()
		ttt_2 = setInterval(function(){
			if(sending_mask_h < 40){
				clearInterval(ttt_2);
				return;
			}else{
				sending_mask_h -= 20;
				sending_mask.css({"height":sending_mask_h + "px", "line-height":sending_mask_h + "px"});
			}
		}, 100);

		file_temp_data = data.base64; //记录图片base64内容
		var total_chunks = Math.ceil(file_temp_data.length / file_chunk_size); //总片数
		ajaxUploadImage(1, total_chunks, data.type, "", sending_img_w, sending_img_h);
	}
}

//ajax切片上传图片
function ajaxUploadImage(index, total, file_type, file_name, img_w, img_h){

	if(file_temp_data == "") return; //无文件数据返回

	var start = (index - 1) * file_chunk_size; //每次传1M
	var curr_data = file_temp_data.substr(start, file_chunk_size);

	if(index === 1){ //第一片
		var json_d = {gid: guest.gid, sess: guest.sess, key: SYSKEY, code: SYSCODE, fileType: file_type, fileData: curr_data, fileIndex: index};
	}else{
		ajax_isOk = 1; //ajax状态需要设置为OK
		var json_d = {gid: guest.gid, sess: guest.sess, key: SYSKEY, code: SYSCODE, fileData: curr_data, fileName: file_name, fileIndex: index};
	}

	ajax(SYSDIR + 'welive-ajax.php?ajax=1&act=upload_img', json_d, function(data){
		if(data.s == 1){ //上传成功后
			//返回的文件名传送给客服
			var save_name = data.i;

			//全部切片上传完成
			if(index >= total){
				file_temp_data = ""; //清空临时数据释放内存
				weliveSend({type: "g_handle", operate: "uploadimg", filename: save_name, width: img_w, height: img_h}); //w,h指图片的宽,高(像素)
				autoOffline(); //重启自动离线
			}else{
				index += 1;
				ajaxUploadImage(index, total, file_type, save_name, img_w, img_h);
			}
		}else{
			file_temp_data = ""; //清空临时数据释放内存
			clearInterval(ttt_2); //上传进度停止
			popInfo(data.i, 8);
			sending_mask.html(langs.upload_failed).css({"color":"red", "font-weight":"bold"});
			welive.status = 1; //允许发送信息
			msger.focus();
		}
	});
}

//上传文件
function weliveUploadFile(){
	var upload_file_input = $("#wl_uploadfile");

	if(upload_file_input[0]){
		upload_file_input[0].click(); //兼容IE
		return;
	}

	var filetype = ["exe", "cmd", "com", "bat", "sys"]; //不允许上传的文件后缀
	var imagetype = ["jpg", "gif", "png", "jpeg"]; //图片文件后缀

	$(".enter").append('<input type="file" id="wl_uploadfile" style="display:none;">');

	upload_file_input = $("#wl_uploadfile");

	upload_file_input.change(function(){
		try {
			if(!welive.status || !checkUploadAuth()) return; //再一次验证状态和授权

			var filepath = $.trim($(this).val());

			if(filepath == "") return;

			var file = this.files[0];
			var filename = file.name;

			var dot_index = filename.lastIndexOf(".");
			var file_ext = filename.substring(dot_index + 1).toLowerCase();

			if(filename == '' || dot_index < 1 || $.inArray(file_ext, filetype) > -1) {
				$(this).val("");
				popInfo(langs.bad_filetype, 8);
				return false;
			}else if($.inArray(file_ext, imagetype) > -1){ //也可以传图片
				readImageFile(file, this); //读取并传送图片			
				return true;
			}

			//判断文件大小
			if (file.size > upload_filesize * 1024*1024) {
				$(this).val("");
				popInfo(langs.bad_filesize + upload_filesize + "M", 8);
				return false;
			}

			var reader = new FileReader();

			reader.onerror = function(e) {
				popInfo(langs.upload_failed, 6);
			};

			var isIE = 0;
			var this_input = $(this);

			reader.onload = function(e) {
				//ajax上传
				welive.status = 0; //上传时不允许发送信息

				if(isIE){ //兼容IE
					var binary = "";
					var bytes = new Uint8Array(e.target.result);
					var length = bytes.byteLength;
					for (var i = 0; i < length; i++) {
						binary += String.fromCharCode(bytes[i]);
					}

					file_temp_data = binary; //记录文件内容
				}else{
					file_temp_data = reader.result; //记录文件内容
				}

				//上传进度条
				var file_str = filename + '<br><div class="uploading_info">' + langs.uploading + '</div><div class="sending_div file_upload"><div class="uploading_mask"></div></div>';

				weliveOutput(file_str, 2, 1); //原生

				sending_mask_h = 250;
				sending_mask = historier.find(".uploading_mask:last"); //仅处理最后一次上传进度, jq1.2.6不支持last()
				ttt_2 = setInterval(function(){
					if(sending_mask_h < 40){
						clearInterval(ttt_2);
						return;
					}else{
						sending_mask_h -= 20;
						sending_mask.css({"width": sending_mask_h + "px"});
					}
				}, 100);

				//ajax切片上传文件
				var total_chunks = Math.ceil(file_temp_data.length / file_chunk_size); //总片数
				ajaxUploadFile(1, total_chunks, file_ext, filename, "");

				this_input.val(""); //清除文件input, 否则无法重复上传相同文件
			};

			if (typeof reader.readAsBinaryString != "undefined") {
				reader.readAsBinaryString(file);
			} else {
				isIE = 1;
				reader.readAsArrayBuffer(file); //兼容IE
			}

		} catch(e) {
			//
		}
	});

	upload_file_input[0].click(); //兼容IE
}


//ajax切片上传文件
function ajaxUploadFile(index, total, file_ext, oldname, file_name){

	if(file_temp_data == "") return; //无文件数据返回

	var start = (index - 1) * file_chunk_size; //每次传1M
	var curr_data = window.btoa(file_temp_data.substr(start, file_chunk_size)); //截取后转为Base64

	if(index === 1){ //第一片
		var json_d = {gid: guest.gid, sess: guest.sess, key: SYSKEY, code: SYSCODE, fileExt: file_ext, fileData: curr_data, fileIndex: index};
	}else{
		ajax_isOk = 1; //ajax状态需要设置为OK
		var json_d = {gid: guest.gid, sess: guest.sess, key: SYSKEY, code: SYSCODE, fileData: curr_data, fileName: file_name, fileIndex: index};
	}

	ajax(SYSDIR + 'welive-ajax.php?ajax=1&act=upload_file', json_d, function(data){

		if(data.s == 1){ //上传成功后
			//返回的文件名传送给客服
			var save_name = data.i;

			//全部切片上传完成
			if(index >= total){
				file_temp_data = ""; //清空临时数据释放内存
				weliveSend({type: "g_handle", operate: "uploadfile", oldname: oldname, filename: save_name});
				autoOffline(); //重启自动离线
			}else{
				index += 1;
				ajaxUploadFile(index, total, file_ext, oldname, save_name);
			}

		}else{
			file_temp_data = ""; //清空临时数据释放内存
			clearInterval(ttt_2); //上传进度停止
			popInfo(data.i, 8);

			historier.find(".uploading_info:last").html("... " + langs.upload_failed).css({"color":"red", "font-weight":"bold"});
			welive.status = 1; //允许发送信息
			msger.focus();
		}
	});
}

//发送由机器人转接人工客服请求
function transToSupport(){
	if(welive.status && welive.isRobot && welive.transOk){
		welive.status = 0; //防止重复发送 
		weliveSend({type: "g_handle", operate: "trans_support"});

		welive.transOk = 0;
		setTimeout(function() {welive.transOk = 1;}, 60000); //60秒后才可能重新申请转接
	}else if(!welive.transOk){
		popInfo(langs.trans_to_failed, 4);
	}else{
		popInfo(langs.notready);
	}
}

//发送服务评价
function sendEvaluate(){
	if(!welive.linked){
		popInfo(langs.notready);
		return false;
	}

	if(rating_star == 0){
		popInfo(langs.select_star);
		return false;
	}

	$("#starRating").hide();
	var msg = $.trim($("#rating_advise").val());

	if(msg.length > 600){
		popInfo(langs.too_long);
		return false;
	}

	weliveSend({type: "g_handle", operate: "rating", star: rating_star, msg: msg});
}

//设置发送信息按钮模式
function setSendMod(mod, me){
	if(mod == send_btn_mod) return;

	send_btn_mod = mod;
	$(me).parent().children().removeClass("curr_send_mod").eq(mod).addClass("curr_send_mod");

	if(send_btn_mod == 1){
		msger.attr("placeholder", "Enter : " + langs.send);
	}else{
		msger.attr("placeholder", "Ctrl + Enter : " + langs.send);
	}

	setCookie(COOKIE_USER + "_sbm", mod, 1000);
}

//调整操作区DIV高度等
function resizeOperateArea(){
	window_width =$(window).width();
	window_height =$(window).height();

	var main_div = $(".main");
	var main_div_height = 780;

	if((window_height - main_div_height) < 4){
		main_div_height = window_height - 4;
	}
	$(".top_div").css({"height": (main_div_height - 30) + "px"});
	main_div.css({"top": (window_height - main_div_height)/2 + "px"});

	scrollBottom();
}


//播放语音
function playVoice(obj){
	var src = $(obj).attr("src");
	if(!src) return;

	if(voicePlayer.src.indexOf(src) !== -1){ //重复点击
		if(voicePlayer.paused) {
			voicePlayer.play();
			$(obj).find(".voice_icon").addClass("playing");
		} else {
			voicePlayer.pause();
			$(obj).find(".voice_icon").removeClass("playing");
		}
	}else{ //新语音
		historier.find(".playing").removeClass("playing");
		$(obj).find(".voice_icon").addClass("playing");
		voicePlayer.src = src;
		voicePlayer.play();

		//播放结束
		voicePlayer.onended = function(){
			$(obj).find(".voice_icon").removeClass("playing");
		};

		//播放错误
		voicePlayer.onerror = function(){
			$(obj).find(".voice_icon").removeClass("playing");
			popInfo(langs.err_play);
		};
	}
}

//发送录音数据
function recorderSend(blob){
	if(!welive.status || welive.isRobot){
		resetRecorder(); //录音复位
		popInfo(langs.notready);
		return;
	}

	var recTime = 60 - timerStart;

	//发送录音(至少1秒)
	if(blob.size && recTime > 0 && voiceURL){
		var ext = (blob.type.toLowerCase().indexOf('ogg') < 0) ? "webm" : "ogg";

		//先输出, 否则FileReader()执行后voiceURL丢失
		var str = '<div class="voice_right noselect" src="' + voiceURL + '" onclick="playVoice(this);"><span class="sec">' + recTime + '"</span><span class="voice_icon"></span></div>';
		weliveOutput(str, 2, 1); //原生

		//发送
		var reader = new FileReader();
		var isIE = 0;

		reader.onerror = function(e) {
			historier.find(".voice_right:last").parents(".msg.r").remove(); //删除最后的语音信息
			popInfo(langs.err_sendvocie, 5);
		};

		reader.onload = function(e){
			var file_data = "";

			if(isIE){ //兼容IE
				var binary = "";
				var bytes = new Uint8Array(e.target.result);
				var length = bytes.byteLength;
				for (var i = 0; i < length; i++) {
					binary += String.fromCharCode(bytes[i]);
				}

				file_data = binary; //记录文件内容
			}else{
				file_data = reader.result; //记录文件内容
			}

			if(file_data){
				welive.status = 0; //先设置为0, 不允许重复录音
				weliveSend({type: "g_handle", operate: "voice", str: window.btoa(file_data), sec: recTime, ext: ext});
				autoOffline(); //重启自动离线
			}else{
				historier.find(".voice_right:last").parents(".msg.r").remove(); //删除最后的语音信息
				popInfo(langs.err_sendvocie, 5);
			}
		};

		if (typeof reader.readAsBinaryString != "undefined") {
			reader.readAsBinaryString(blob);
		} else {
			isIE = 1;
			reader.readAsArrayBuffer(blob); //兼容IE
		}

	}else{
		popInfo(langs.err_short);
	}

	resetRecorder(); //录音复位
}

//开始录音
function recorderStart(){
	if(wRecorder || !userAudioStream) return; //录音中不允许重复操作 或者 没有开启录音权限资源返回

	wRecorder = RecordRTC(userAudioStream, {
		type: 'audio',
		mimeType: mimeCodec,
		disableLogs: true,
		getNativeBlob: true, //原生blob			
		audioBitsPerSecond: sampleRate //录音比特率, 默认为128000 = 128K, 其中推荐16K 24k 32K录音较小
	});

	//60秒自动停止
	wRecorder.setRecordingDuration(60000, function() {
		voiceURL = this.toURL(); //记录当前blob的URL
		var blob = this.getBlob();
		recorderSend(blob); //发送录音
		resetRecorderTip(); //录音提示器复位
		micButton.removeClass("down").html(langs.press_say);
	});

	wRecorder.startRecording();

	//显示tip等
	recorderTip.show();
	micButton.addClass("down").html(langs.release_send);

	//开启定时器
	rec_ttt = setInterval(function() {
		timerStart -= 1;
		if(timerStart < 0) timer_start = "0";
		timer.html(timerStart);
	}, 1000);
}

//初始化录音按钮
function initMicphoneBtn(){
	var status = false;

	micButton.mousedown(function(e) {
		e.preventDefault(); //禁止长按选中

		if(!welive.status || !welive.linked || welive.isRobot){
			popInfo(langs.notready);
			return;
		}

		status = true;
		recorderStart(); //开始录音

	}).mouseup(function(e){
		e.preventDefault(); //禁止长按选中

		//发送录音
		if(status){
			status = false;
			$(this).removeClass("down").html(langs.press_say);

			if(wRecorder){
				if(wRecorder.state != "stopped"){
					wRecorder.stopRecording(function() {
						voiceURL = this.toURL(); //记录当前blob的URL

						var blob = this.getBlob();
						recorderSend(blob); //发送
					});
				}

				resetRecorderTip(); //录音提示器复位
			}
		}

	}).mouseout(function(e){
		if(!status || !wRecorder) return; //未按下 或 未录音
		status = false;

		//变更tip内容
		timer.hide();
		recorderTip.children(".tip_recording").hide();
		recorderTip.children(".tip_cancel").show();
		recorderTip.children(".tip_info").addClass("warning").html(langs.tip_release);

		$(this).removeClass("down").html(langs.press_say);

		//终止录音
		if(wRecorder.state != "stopped") wRecorder.stopRecording();
		resetRecorder();

		$(document).one("mouseup", resetRecorderTip); //关闭tip
	});
}

//录音复位
function resetRecorder(){
	voiceURL = "";
	timerStart = 60;
	clearInterval(rec_ttt); //终止定时器

	if(wRecorder) wRecorder = null;
}

//录音提示器复位
function resetRecorderTip(){
	recorderTip.hide();
	timer.html("60").show();
	recorderTip.children(".tip_recording").show();
	recorderTip.children(".tip_cancel").hide();
	recorderTip.children(".tip_info").removeClass("warning").html(langs.tip_slidetop);
}


//welive初始化
function weliveInit(){
	sender = $("#sender_msg");
	sounder = $("#wl_sounder");
	send_mod_div = $("#send_mod_div");

	pagetitle = document.title;

	weliveLink(); //socket连接

	//工具栏按钮, 发送截图, 发送模式的title
	showTitle("div.tool_bar_i, .how_sendimg, #send_mod_btn");

	$(window).resize(function(){
		resizeOperateArea();
	});

	//发送信息
	msger.keydown(function(e){
		var e = e||event, keyCode=e.keyCode||e.which||e.charCode;
		if((send_btn_mod == 0 && e.ctrlKey && keyCode == 13) || (send_btn_mod == 1 && keyCode == 13)){
			weliveSendMsg();
			e.preventDefault();
		}	
	});   

	//发送信息
	sender.click(function(e) {
		weliveSendMsg();
		e.preventDefault();
	});

	//评价按钮动作
	$("#toolbar_evaluate").click(function(){
		rating_star = 0;
		$("#starRating .star span").find('.high').css('z-index',0);
		$(".starInfo").html(langs.select_star);
		$("#starRating").toggle();
	});

	//评价层
	$("#starRating").mouseover(function(){
		clearTimeout(ttt_4);
	}).mouseout(function(){
		var me = $(this);
		ttt_4 = setTimeout(function(){
			me.hide();
		}, 800);
	});

	//星星打分
	$("#starRating .star span").mouseover(function () {
		rating_star = parseInt($(this).attr("star_val"));

		$(this).prevAll().find('.high').css('z-index',1);
		$(this).find('.high').css('z-index',1);
		$(this).nextAll().find('.high').css('z-index',0);

		$('.starInfo').html(star_info[rating_star -1]);
	});

	//表情符号
	$("#toolbar_emotion").mouseover(function(){
		clearTimeout(ttt_4);
		smilies_div.show();
	}).mouseout(function(){
		ttt_4 = setTimeout(function() {
			smilies_div.hide();
		}, 800);
	});

	smilies_div.mouseover(function(){
		clearTimeout(ttt_4);
	}).mouseout(function(){
		ttt_4 = setTimeout(function() {
			smilies_div.hide();
		}, 800);
	});

	//开关声音
	sound_btn.click(function(){
		if(welive.sound){
			welive.sound = 0;
			sound_btn.addClass('sound_off');
			setCookie(COOKIE_USER + "_soff", 1, 2); //关闭声音cookie保持2天		
		}else{
			welive.sound = 1;
			sound_btn.removeClass('sound_off');
			sounder.html(welive.mp3);
			setCookie(COOKIE_USER + "_soff", 0, 0);
		}
		msger.focus(); //输入框焦点
	});

	//监听上传图片控件
	$("#upload_img").change(function(){
		try {
			var file = this.files[0];
			readImageFile(file, this); //读取并传送图片
		} catch(e) {}
	});

	//上传图片按钮
	$("#toolbar_photo").click(function(){
		$("#welive_div_toop").hide(); //隐藏title

		if(!welive.status || !welive.linked){
			popInfo(langs.notready);
			return;
		}

		//验证上传图片权限
		if(welive.isRobot){
			popInfo(langs.no_upload_robot);
			return;
		}

		//$("#upload_img").trigger("click"); //Jquery1.2.6不兼容IE
		document.getElementById("upload_img").click(); //兼容IE
		return false;
	});

	//上传文件按钮
	$("#toolbar_file").click(function(){
		$("#welive_div_toop").hide(); //隐藏title

		if(!welive.status || !welive.linked){
			popInfo(langs.notready);
			return;
		}

		//验证上传权限
		if(!checkUploadAuth()) return;		
		weliveUploadFile();
	});

	//短语音工具按钮
	$("#toolbar_voice").click(function(){
		//切换成文本框
		if($(this).hasClass("keyboard")){
			//关闭录音资源, 消除录音红点
			if(userAudioStream){
				userAudioStream.stop();
				userAudioStream = null;
			}
			
			$(this).removeClass("keyboard");
			$("#welive_div_toop").html(langs.send_voice);
			this.Mytitle = langs.send_voice;

			micButton.hide();
			msger.show().focus();
			return;
		}

		if(!welive.status || !welive.linked || welive.isRobot){
			popInfo(langs.notready);
			return;
		}

		//检测环境
		if(!userNavigator.getUserMedia){
			popInfo(langs.unsupported, 5);
			return;
		}

		var _this = this;

		//先授权使用mic
		userNavigator.getUserMedia({
			audio:{
				sampleRate: sampleRate,
				channelCount: 1, //双声道时有噪音
				volume: 1.0
			}
		}).then(function(stream){
			userAudioStream = stream;

			//切换成micphone按钮
			$(_this).addClass("keyboard");
			$("#welive_div_toop").html(langs.send_text);
			_this.Mytitle = langs.send_text;

			micButton.show();
			msger.val("").hide(); //清空输入框, 消除实时输入信息

		}).catch(function(err){
			popInfo(langs.unauthmic, 5); //未授权录音或不支持mic
		});
	});

	//初始化录音按钮
	initMicphoneBtn();

	//发送模式按钮及选择层
	$("#send_mod_btn").click(function(){	send_mod_div.toggle();}).mouseout(function(){ttt_4 = setTimeout(function(){send_mod_div.hide();}, 600);});
	send_mod_div.mouseover(function(){	clearTimeout(ttt_4);}).mouseout(function(){ttt_4 = setTimeout(function(){send_mod_div.hide();}, 600);});


	//停止标题闪烁、禁止刷新
	$(document).mousedown(stopFlashTitle).keydown(function(e){
		stopFlashTitle();

		var e = e||event, keyCode=e.keyCode||e.which||e.charCode;

		//status正常时, 禁止F5, ctrl或shift + F5或R键 刷新
		if(welive.status && (keyCode == 116 || ((e.ctrlKey || e.shiftKey) && (keyCode == 82 || keyCode == 116))) ){
			popInfo(langs.not_refresh);
			e.returnValue = false;
			e.cancelBubble = true;
			e.keyCode = e.which = e.charCode = 0;
			e.preventDefault();
			return false;
		}
	});

	welive.mp3 = '<audio src="' + SYSDIR + 'public/sound_f.mp3" autoplay="autoplay"></audio>';

	//状态正常时, 离开当前页面时提示选择及动作
	window.onbeforeunload=function(event){
		if(welive.status){
			return " ";
		}else{
			clearTimer();
		}		
	};

	$(window).unload(function(){clearTimer();});
}

//定义全局变量
var WebSocket = window.WebSocket || window.MozWebSocket; //websocket

var ttt_1 = 0, ttt_2 = 0, ttt_3 = 0, ttt_4 = 0, ttt_5 = 0, ttt_6 = 0, rating_star = 0, pagetitle, flashtitle_step = 0, sounder, sound_btn, sending_mask, sending_mask_h, send_btn_mod = 1, send_mod_div;
var welive_op, welive_cprt, history_wrap, historier, new_info, sender, msger, smilies_div;

var welive_name; //客服姓名
var welive_duty; //客服职位

var window_width, window_height; //屏幕宽和高px

var file_chunk_size = 1048576; //切片大小 默认为1M
var file_temp_data = ""; //切片上传文件时使用

//短语音相关
var sampleRate = 16000; //录音比特率, 其中推荐 16000  24000  32000 录音文件较小
var mimeCodec = 'audio/webm'; //语音解码类型
var voicePlayer, voiceURL = '', recorderTip, rec_ttt = 0, timer, timerStart = 60, micButton, wRecorder, userNavigator, userAudioStream = null;


//linked        1已连接,   0未连接
//status        1登录成功允许发信息,   0不允许发信息
//autolink     1允许重新连接,   0不允许重新连接
var welive = {ws:{}, ttt: 0, ttt2: 0, linked: 0, status: 0, autolink: 0, unread: 0, flashTitle: 0, sound: 1, mp3: '', msg: '', closeQuiet: 0, temp: '', isRobot: 0, transOk: 1};

var star_info = ['<img src="' + SYSDIR + 'public/img/star_icon1.png">' + langs.star_1, '<img src="' + SYSDIR + 'public/img/star_icon2.png">' + langs.star_2, '<img src="' + SYSDIR + 'public/img/star_icon3.png">' + langs.star_3, '<img src="' + SYSDIR + 'public/img/star_icon4.png">' + langs.star_4, '<img src="' + SYSDIR + 'public/img/star_icon5.png">' + langs.star_5];


//页面加载完成
$(function(){
	welive_op = $("#welive_operator");
	welive_cprt = $("#welive_copyright");
	sound_btn = $("#toolbar_sound");
	msger = $("#guest_msg");
	smilies_div = $(".smilies_div");
	history_wrap = $(".history");
	historier = history_wrap.find(".overview");
	new_info = $("#new_info");

	//短语音相关
	timer = $("#timer");
	recorderTip = $("#recorder_tip");
	micButton = $("#mic_button");
	voicePlayer = document.getElementById("voice_player"); //语音播放器

	//调整操作区高度及位置
	resizeOperateArea();

	//获取客人的gid
	var gid = parseInt(getCookie(COOKIE_USER));
	if(gid) guest.gid = gid;

	if(WS_HOST == "")	WS_HOST = document.domain; //先记录下来供websocket连接使用

	//获取当前的声音状态
	var wl_soundoff = parseInt(getCookie(COOKIE_USER + "_soff"));
	if(wl_soundoff == 1){
		welive.sound = 0;
		sound_btn.addClass('sound_off');
	}

	//初始化发送按钮模式
	send_btn_mod = getCookie(COOKIE_USER + "_sbm");
	if(!send_btn_mod) send_btn_mod = 1;
	if(send_btn_mod == 0) msger.attr("placeholder", "Ctrl + Enter : " + langs.send);
	$(".send_mod_" + send_btn_mod).addClass("curr_send_mod");


	weliveInit(); //welive初始化

	//兼容性处理
	userNavigator = navigator.mediaDevices||{};
	if(!userNavigator.getUserMedia){
		userNavigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia;
	}

	//常见问题
	$("#common_questions li").click(function(){
		var txt = $(this).text();
		msger.val(txt);
		msger.focus();
	});

	//监听剪切板发送图片, 不支持IE
	msger.bind("paste", function(event){
		//访客窗口输入框未获得焦点时, 不允许发送图片
		if(document.activeElement.id != "guest_msg") return;
		if(!(event.clipboardData || event.originalEvent)) return; //IE不支持

		var clipboardData = (event.clipboardData || event.originalEvent.clipboardData);
		if(!clipboardData.items) return;

		var items = clipboardData.items;
		var blob = null;

		//在items里找粘贴的image
		for (var i = 0; i < items.length; i++) {
			if (items[i].type.indexOf("image") !== -1) {
				blob = items[i].getAsFile();
				break;
			}
		}

		if(blob !== null) {
			//如果剪贴板内容为图片, 阻止默认行为, 即不让剪贴板内容显示出来
			event.preventDefault();

			var reader = new FileReader();

			reader.onload = function (e) {
				var base64_str = e.target.result; //图片的Base64编码字符串

				var img = new Image();
				img.src = reader.result;

				img.onload = function() {
					var w = img.width, h = img.height;

					var canvas = document.createElement('canvas');

					var ctx = canvas.getContext('2d');
					$(canvas).attr({width: w,	height: h});
					ctx.drawImage(img, 0, 0, w, h);

					var base64 = canvas.toDataURL("image/jpg", 0.6); //转成jpg

					var result = {
						url: base64_str,
						w: w,
						h: h,
						size: base64.length,
						type: "image/jpg",
						base64: base64.substr(base64.indexOf(',') + 1),
					};

					weliveSendImage(result);
				};
			}

			reader.readAsDataURL(blob); 
		}
	});
});