/**
 * 下面的主要封装和vue使用见：https://blog.csdn.net/xzx66666/article/details/126570697
 * 具体逻辑参考welive的guest.js文件。
 *
 * @type {{msg: string, flashTitle: number, transOk: number, temp: string, isRobot: number, autolink: number, unread: number, closeQuiet: number, sound: number, ttt2: number, mp3: string, ttt: number, ws: {}, linked: number, status: number}}
 */
import jyRquest from '../api/request.js';
//linked        1已连接,   0未连接
//status        1登录成功允许发信息,   0不允许发信息
//autolink     1允许重新连接,   0不允许重新连接
var welive = {ws:{}, ttt: 0, ttt2: 0, linked: 0, status: 0, autolink: 0, unread: 0, flashTitle: 0, sound: 1, mp3: '', msg: '', closeQuiet: 0, temp: '', isRobot: 0, transOk: 1};
// 传参对象
var COOKIE_KEY = 'vsdfasdasd' ; //'';
// var COOKIE_KEY = 'vsdfasdasd';
var COOKIE_USER = COOKIE_KEY + 'user';
var WS_HOST = "39.105.5.113";
var WS_HEAD = "ws://";
var WS_PORT = "8620";
// 传参对象
var guest = {grid: '1', gid: 0, oid: '0', fn: "", aid: 0, au: 0, sess: "", lang: 1, agent: "Chrome 86.0.4240.198", fromurl: "http://"+WS_HOST+":"+WS_PORT+"/"}
var SYSKEY =  ''; // '' + Math.random(); //'vsdfasdasd';
// var SYSCODE = 'fb72G9sdFkh07rWslCPGvbBzJUyIyFSDh3b3VeZML9eWbm6k7W4ItzCFqsogQYWUUA6Iwjaznw/HMZ5F4Q';
var SYSCODE = '';
const weliveApi = "";

//获取客人的gid
var gid = parseInt(getCookie(COOKIE_USER));
if(gid) guest.gid = gid;

// 如何开启才调用，否则的话。
if(Glod.hsaLive){
    jyRquest.post({
        url: 'system/proxy',
        headers: {
            'Content-Type': 'application/json',
            'X-URL':  Glod.weliveApi + `/welive-ajax.php?ajax=1&act=auth`,
            'X-METHOD': 'GET',
        },
        data: {}
    }).then(res => {
        console.log('=======live==tr/proxy==============', res);
        let message = JSON.parse(res.message);
        SYSKEY = message.key;
        SYSCODE = message.code;
    }).catch(reason => {
        console.log('======catch===reason==============', reason);
    });
}



var ttt_1 = 0, ttt_2 = 0, ttt_3 = 0, ttt_4 = 0, ttt_5 = 0, ttt_6 = 0, rating_star = 0, pagetitle, flashtitle_step = 0, sounder, sound_btn, sending_mask, sending_mask_h, send_btn_mod = 1, send_mod_div;
var welive_name = '人工客服'; //客服姓名
var welive_duty = '客服经理'; //客服职位
var langs = {
    'welive' : '在线客服',
    'msg' : '新消息',
    'send' : '发 送',
    'notinput' : '未输入',
    'notready' : '未就绪',
    'failed' : '连接失败，请稍后重试！',
    'relink' : '连接失败, 6秒后自动重试 ...',
    'send_mode' : '发送模式',
    'not_refresh' : '正在对话中, 请勿刷新页面！',
    'trans_to' : '转人工客服',
    'trans_to_m' : '转人工',
    'shutdown' : '抱歉, 客服系统维护中!',
    'connecting' : '正在为您连接客服 ...',
    'offline' : ' 暂时离线, 60秒后仍未上线, 将为你转接其他客服, 请稍候 ...',
    'aback' : ' 重新上线了!',
    'autooff' : '长时间无会话, 已自动离线!',
    'kickout' : '抱歉! 您被请出了客服.',
    'banned' : '抱歉! 您被禁止发言了.',
    'transfer' : '当前会话已经转接至客服: ',
    'records' : '... 以上为最近对话记录',
    'relinked' : '已在其它窗口中连接了客服.',
    'rebtn' : '重新连接',
    'emotions' : '表情',
    'sendphoto' : '发送图片',
    'sendfile' : '发送文件',
    'sound' : '声音',
    'evaluate' : '评价',
    'common_questions' : '常见问题',
    'type_question' : '请输入您的问题 ...',
    'uploading' : '文件上传中 ...',
    'img_limit' : '图片文件不能超过10M',
    'img_badtype' : '图片文件格式无效',
    'upload_failed' : '上传失败',
    'upload_done' : '上传成功',
    'no_upload_auth' : '请先向客服申请上传授权',
    'no_upload_robot' : '机器人工作时无法上传图片或文件',
    'got_upload_auth' : '您已获取上传文件授权',
    'upload_alert' : '您一小时内上传了太多文件',
    'badcookie' : '验证码已过期, 请刷新页面后重试!',
    'trans_to_failed' : '抱歉, 暂无客服在线, 无法转接人工！',
    'nosuppert' : '暂无客服在线',
    'rating_title' : '您对本次服务满意吗？',
    'select_star' : '请选择评价',
    'rating_advise' : '恳请您的意见和建议！',
    'star_1' : '极差',
    'star_2' : '较差',
    'star_3' : '一般',
    'star_4' : '满意',
    'star_5' : '非常满意',
    'too_long' : '您的附言太长',
    'rating_thanks' : '感谢您对本次服务提交了评价！',
    'rating_limit' : '评价失败, 每天对同一客服的评价限2次',
    'submit' : '提 交',
    'readed' : '已读',
    'unread' : '未读',
    'team_off' : '当前客服组不存在或已关闭!',
    'msg_too_long' : '您输入的信息太长了!',
    'bad_filetype' : '文件格式不允许, 如要发送图片请点击左侧图片按钮',
    'bad_filesize' : '文件大小不能超过: ',
    'click_download' : '点击下载: ',
    'search_result' : '常见问题 搜索结果: ',
    'how_sendimg' : '怎样发截图？',
    'how_sendimg_title' : '用QQ等软件截图后, 在输入框中粘贴即可',
    'send_voice' : '发送短语音',
    'send_text' : '发送文本',
    'unsupported' : '浏览器(http)不支持语音',
    'unauthmic' : '浏览器未授权使用麦克风',
    'press_say' : '按住 说话',
    'release_send' : '松开 发送',
    'tip_slidetop' : '手指上划，取消发送',
    'tip_release' : '松开手指，取消发送',
    'err_sendvocie' : '语音发送失败',
    'err_short' : '语音太短',
    'err_play' : '播放错误，文件不存在',
    'draw_back' : '对方撤回了一条消息',
};

var global_callback = null;
var wsuri = Glod.weliveWS;

function createWebSocket(callback) {
    if (welive.ws == null || typeof welive.ws !== WebSocket) {
        global_callback = callback;
        weliveLink();
    }
}

function weliveLink() {
    // 初始化websocket
    welive.ws = new WebSocket(wsuri);
    welive.ws.onmessage = function (e) {
        // websocketonmessage(e);    // 原格式。
        weliveParseOut(e);   // welive的格式。
    };
    welive.ws.onclose = function (e) {
        websocketclose(e);
    };
    welive.ws.onopen = function () {
        websocketOpen();
    };

    // 连接发生错误的回调方法
    welive.ws.onerror = function () {
        console.log("WebSocket连接发生错误");
        //createWebSocket();啊，发现这样写会创建多个连接，加延时也不行
    };
}

// 实际调用的方法
function sendSock(agentData ) {

    if (welive.ws.readyState === welive.ws.OPEN) {
        // 若是ws开启状态
        websocketsend(agentData);
    } else if (welive.ws.readyState === welive.ws.CONNECTING) {
        // 若是 正在开启状态，则等待1s后重新调用
        setTimeout(function () {
            sendSock(agentData);
        }, 1000);
    } else {
        // 若未开启 ，则等待1s后重新调用
        setTimeout(function () {
            sendSock(agentData);
        }, 1000);
    }
}



// 数据接收
function websocketonmessage(msg) {
    // console.log("收到数据："+JSON.parse(e.data));
    // console.log("收到数据："+msg);

    // global_callback(JSON.parse(msg.data));

    // 收到信息为Blob类型时
    let result = null;
    // debugger
    if (msg.data instanceof Blob) {
        const reader = new FileReader();
        reader.readAsText(msg.data, "UTF-8");
        reader.onload = (e) => {
            result = JSON.parse(reader.result);
            //console.log("websocket收到", result);
            global_callback(result);
        };
    } else {
        result = JSON.parse(msg.data);
        //console.log("websocket收到", result);
        global_callback(result);
    }
}

//将json数据转换成json对象
function parseJSON(data) {
    if(window.JSON && window.JSON.parse) return window.JSON.parse(data);
    if(data === null) return data;
    if(typeof data === "string") {
        data = $.trim(data);
        if(data) {
            var rvalidchars = /^[\],:{}\s]*$/,
                rvalidbraces = /(?:^|:|,)(?:\s*\[)+/g,
                rvalidescape = /\\(?:["\\\/bfnrt]|u[\da-fA-F]{4})/g,
                rvalidtokens = /"[^"\\\r\n]*"|true|false|null|-?(?:\d+\.|)\d+(?:[eE][+-]?\d+|)/g;

            if(rvalidchars.test(data.replace(rvalidescape, "@").replace(rvalidtokens, "]").replace(rvalidbraces, ""))) {
                return (new Function("return " + data))();
            }
        }
    }
    return false;
}

//获取cookie
function getCookie(n) {
    var a = document.cookie.match(new RegExp("(^| )" + n + "=([^;]*)(;|$)"));
    if (a != null) return a[2];
    return '';
}
//记住访客id, 上传session会话
function rememberGuest(gid, sess){
    gid = parseInt(gid);

    if(!guest.gid || guest.gid != gid){
        guest.gid = gid; //更新ID号
        setCookie(COOKIE_USER, gid, 3650); //写cookie
    }

    //产生一个session会话记录, 用于验证上传图片等, 以免产生非法操作
    guest.sess = sess; //解决safari禁止第三方cookie的问题
    setCookie(COOKIE_USER + "_sess", sess, 0); //随进程消失, 上传文件等时首先验证
}
//设置cookie
function setCookie(n,val,d) {
    var e = "";
    if(d) {
        var dt = new Date();
        dt.setTime(dt.getTime() + parseInt(d)*24*60*60*1000);
        e = "; expires="+dt.toGMTString();
    }
    document.cookie = n+"="+val+e+"; path=/";
}
//解析数据并输出
function weliveParseOut(get){
    var d = false, type = 0, raw = 0, data = parseJSON(get.data);
    if(!data) return; //没有数据返回

    switch(data.x){

        case 5: //客人与客服文字对话
            if(data.a == 1){ //客服发来的
                welive.flashTitle = 1;
                type = 1; d = data.i;

                //机器人工作时
                if(welive.isRobot){
                    // historier.find("s.un").html(langs.readed).removeClass("un"); //已读
                    welive.status = 1; //机器人回复输出后才能发送第二条
                    if(typeof data.av != 'undefined' && data.av != ''){
                        clearTimeout(ttt_5);
                        // toggleAvatar(data.av); //变换头像
                        //
                        // ttt_5 = setTimeout(function() {
                        //     welive_op.find("#welive_avatar").attr("src", SYSDIR + "avatar/robot/0.png");
                        // }, 30000); //30秒后头像恢复
                    }
                    // historier.children(".robot_typing").remove(); //清除机器人思考标志
                    weliveOutput(d, type, raw); //输出
                    return;
                }
            }else{ //自己发出的对话
                type = 2;
                if(!welive.isRobot) welive.status = 1; //发送完成允许发送第二条信息

                d = welive.msg.replace(/</g, "&lt;").replace(/>/g, "&gt;"); //防止自己发js代码时发生显示错误
                welive.msg = ''; //清空临时信息
            }

            break;

        case 8: //人工客服发来的标记已读信息

            // historier.find("s.un").html(langs.readed).removeClass("un");
            return true;

            break;

        case 6: //客人特别操作或返回信息
            switch(data.a){

                case 8: //客人登录成功
                    welive.status = 1; //允许发信息
                    welive.autolink = 6; //允许自动重连6次

                    welive.isRobot = parseInt(data.irb); //系统是否为无人值守状态

                    guest.fn = data.fn; //客人姓名
                    guest.aid = parseInt(data.aid); //更新客服的id, 重新连接时用
                    guest.an = data.an; //客服姓名
                    guest.au = parseInt(data.au); //上传授权, 强制转成数字1或0, 方便判断, JS里if("0") 是true, php里为false

                    //更新头像及身份
                    // welive_name = data.an;
                    // welive_duty = data.p;
                    // welive_op.find("#welive_avatar").attr("src", SYSDIR + "avatar/" + data.av);
                    // welive_op.find("#welive_name").html(welive_name);
                    // welive_op.find("#welive_duty").html(welive_duty);

                    // historier.removeClass('loading3'); //去掉loading样式

                    // msger.focus();
                    welive.flashTitle = 1;
                    // type = 8;
                    type = 3; // 改成3正常提示。
                    d = '连接成功';
                    // d = welcome;
                    raw = 1; //原生的, 不解析html

                    // outputRecords(data.re); //输出对话记录

                    rememberGuest(data.gid, data.sess); //记住访客id, 上传session会话

                    // autoOffline(); //启动自动离线

                    // if(welive.isRobot) {
                    //     $("#toolbar_transto").show();
                    //     $("#toolbar_voice").hide();
                    // }else{
                    //     welive.temp = '';
                    //     weliveRuntime(); //非机器人服务时, 启动实时输入状态
                    //     $("#toolbar_transto").hide();
                    //     $("#toolbar_voice").show();
                    // }

                    //启动心跳, 即每隔26秒自动发送一个特殊信息, 解决IE下30秒自动断线的问题
                    //设置一个怪异的数字避免与自动离线的时间间隔重合, 避免在同一时间点上send数据时, 可能产生-----幽灵bug
                    ttt_1 = setInterval(function() {
                        weliveSend({type: "ping"});
                    }, 26125);

                    break;

                case 1: //客服重新上线
                    clearTimeout(welive.ttt2); //清除客服离线时自动转接

                    setTwoStatus(1); //状态正常, 允许重连
                    welive.flashTitle = 1;
                    type = 3; d = welive_name + langs.aback;

                    break;

                case 2: //客服离线
                    welive.status = 0;
                    welive.flashTitle = 1;
                    type = 4; d = welive_name + langs.offline;

                    //1分钟后发送请求重新分配客服的请求
                    welive.ttt2 = setTimeout(function(){
                        weliveSend({type: "g_handle", operate: "redistribute"});
                    }, 59973);

                    break;

                case 4: //重复连接
                case 5: //自动离线
                    type = 4;
                    setTwoStatus(0); //状态未正常, 不允许重连
                    setDefaultAvatar(); //设为初始头像
                    d = (data.a == 4 ? langs.relinked : langs.autooff) + '<br><a onclick="weliveLink();$(this).parents(\'.msg\').hide();return false;" class="relink">' + langs.rebtn + '</a>';

                    break;

                case 6: //被踢出
                    setTwoStatus(0);
                    setDefaultAvatar(); //设为初始头像
                    type = 4; d = langs.kickout;

                    break;

                case 7: //被禁言
                    setTwoStatus(0);

                    welive.flashTitle = 1;
                    type = 4; d = langs.banned;

                    break;

                case 9: //无客服在线 或 客服组不存在或关闭时 或 禁言中
                    setTwoStatus(0);
                    type = 4;
                    d = langs.nosuppert; //客服不在线

                    if(data.i == "nogroup"){
                        d = langs.team_off; //客服组不存在或关闭
                    }else if(data.i == "banned"){
                        d = langs.banned; //禁言中
                    }

                    setDefaultAvatar(); //设为初始头像

                    break;

                case 11: //被转接
                    setTwoStatus(1);

                    if(welive.isRobot) clearTimeout(ttt_5); //转接前是机器人服务时, 阻止机器人头像延迟变换
                    welive.isRobot = parseInt(data.irb); //系统是否为无人值守状态

                    guest.aid = data.aid; //更新客服的id, 重新连接时用
                    guest.an = data.an; //客服姓名
                    guest.au = parseInt(data.au); //上传权限

                    //更新头像及身份
                    // welive_name = data.an;
                    // welive_duty = data.p;
                    //
                    // welive_op.find("#welive_avatar").attr("src", SYSDIR + "avatar/" + data.av);
                    // welive_op.find("#welive_name").html(welive_name);
                    // welive_op.find("#welive_duty").html(welive_duty);

                    //机器人服务时, 转人工服务按钮状态等
                    // if(welive.isRobot) {
                    //     clearInterval(ttt_6); //清除提交实时输入状态
                    //     $("#toolbar_transto").show();
                    //     $("#toolbar_voice").hide();
                    // }else{
                    //     welive.temp = '';
                    //     weliveRuntime(); //启动实时输入状态
                    //     $("#toolbar_transto").hide();
                    //     $("#toolbar_voice").show();
                    // }

                    // msger.focus();
                    welive.flashTitle = 1;
                    type = 4; d = langs.transfer + data.an;

                    break;

                case 14: //评价返回
                    msger.focus();

                    if(data.s == "1"){
                        welive.flashTitle = 1;
                        type = 1; d = '<font color=red>' + langs.rating_thanks + '</font>[:16:]';
                    }else{
                        popInfo(langs.rating_limit, 6);
                        return false;
                    }

                    break;

                case 15: //请求转人工客服 返回

                    welive.status = 1;
                    msger.focus();

                    if(data.s == "2"){
                        popInfo(langs.trans_to_failed, 4);
                    }

                    return true;

                    break;
            }

            break;

        case 7: //上传图片等
            switch(data.a){

                case 1: //客服授权上传
                    if(!allow_uploadfile || (allow_uploadfile && !auth_upload)) return false; //屏蔽客服授权信息

                    guest.au = 1;
                    msger.focus();
                    welive.flashTitle = 1;
                    type = 3; d = langs.got_upload_auth;

                    break;

                case 2: //客人上传图片通知客服后返回的信息--表示上传成功

                    //进度条消失(指最后一个上传图片的进度条)
                    // sending_mask.remove();

                    welive.status = 1; //允许发送信息
                    // msger.focus();

                    break;

                case 4: //客服发来的图片

                    type = 1; //客服发来的
                    welive.flashTitle = 1; //声音
                    raw = 1; //原生的

                    if(data.w <1) data.w = 1;
                    var img_h = parseInt(data.h * 250 / data.w); //CSS样式中已确定宽度为250

                    d = '<div class="sending_div" style="height:' + img_h + 'px;"><img src="' + SYSDIR + 'upload/img/' + data.i + '" class="sending_img" onclick="showImage(this, ' + data.w + ', ' + data.h + ');"></div>';

                    break;

                case 5: //客人上传文件通知客服后返回的信息--表示上传成功

                    //进度条消失(指最后一个上传文件的进度条)
                    historier.find(".uploading_info:last").html("... " + langs.upload_done).css({"color":"blue", "font-weight":"bold"});

                    //sending_mask.remove();
                    historier.find(".uploading_mask:last").parent().fadeOut(1000, function(){
                        $(this).remove();
                    });

                    welive.status = 1; //允许发送信息
                    msger.focus();

                    break;

                case 6: //客服上传文件
                    type = 1; //客服发来的
                    welive.flashTitle = 1; //声音
                    raw = 1; //原生的

                    d = '<a href="' + SYSDIR + 'upload/file/' + data.i + '" target="_blank" download="' + data.o + '" class="down"><img src="' + SYSDIR + 'public/img/save.png">&nbsp;&nbsp;'  + langs.click_download +  data.o + '</a>';

                    break;

                case 7: //客服发来的短语音
                    type = 1; //客服发来的
                    welive.flashTitle = 1; //声音
                    raw = 1; //原生的

                    var d = '<div class="voice_left" src="' + SYSDIR + 'upload/file/' + data.i + '" onclick="playVoice(this);"><span class="sec">' + data.s + '"</span><span class="voice_icon"></span></div>';

                    break;

                case 8: //自己发送语音返回
                    welive.status = 1; //允许再录音

                    if(data.i == "err"){
                        historier.find(".voice_right:last").parents(".msg.r").remove(); //删除最后的语音信息
                        popInfo(langs.err_sendvocie, 5);
                    }

                    break;

                case 9: //客服撤回一条消息

                    type = 3; d = langs.draw_back;
                    historier.find(".msg.l:last").remove();

                    break;
            }

            break;
    }

    weliveOutput(d, type, raw); //输出
}
// 数据发送
function websocketsend(agentData) {
    console.log("发送数据：" + agentData);
    // welive.ws.send(agentData);
    weliveSend(agentData);
}

// 关闭
function websocketclose(e) {
    welive.linked = 0; //标记连接失败
    clearTimer(); //清理定时器

    //允许重连时
    if(welive.autolink > 0){
        welive.closeQuiet = 0;
        welive.autolink -= 1;
        weliveOutput(langs.relink, 3);
        setTimeout(function(){weliveLink();}, 6000); //6秒后自动重连
        return false;
    }

    //不允许重连时
    if(welive.closeQuiet){
        welive.closeQuiet = 0;
    }else{
        weliveOutput(langs.failed, 4);
    }
}


function websocketOpen(e) {
    console.log("连接打开");
    welive.linked = 1; //websocket连接成功
    welive.closeQuiet = 1; //连接成功后, websocket连接断开时不显示: 连接失败，请稍后重试
    setTimeout(function(){weliveVerify();}, 100); //连接成功后, 小延时再验证用户, 否则IE下刷新时发送数据失败
}

//访客连接验证
function weliveVerify(){
    weliveSend({type: "login", from: "front", gid: guest.gid, grid: guest.grid, oid: guest.oid, fn: guest.fn, au: guest.au, aid: guest.aid, lang: guest.lang, key: SYSKEY, code: SYSCODE, fromurl: guest.fromurl, agent: guest.agent, mobile: 0});
}

//发送信息(直接)
function weliveSend(d){
    var re = 0;

    if(welive.linked){
        re = 1;
        welive.ws.send(JSON.stringify(d)); //将json对象转换成字符串发送
    }else{
        popInfo(langs.notready);
    }

    return re; //回返是否成功
}
//离开页面或断线时清理定时器
function clearTimer(){
    console.log('---clearTimer-----clearTimer')
    welive.status=0;
    clearTimeout(welive.ttt); //自动离线
    clearTimeout(welive.ttt2); //客服离线时自动转接
    clearInterval(ttt_1); //发送心跳数据
    clearInterval(ttt_2); //上传进度条
    clearInterval(ttt_3); //标题闪烁
    clearInterval(ttt_6); //实时输入状态
}


//弹出消息
function popInfo(info, sec){
    console.log('---弹出消息----',info, sec)
    if(sec){
        // layer.msg(info, {time: sec * 1000});
    }else{
        // layer.msg(info);
    }
}
//交流输出信息, raw为true时不解析html
/**
 *
 * @param d 生成的div
 * @param type 类型
 * @param raw  raw = 1; //原生的, 不解析html
 */
function weliveOutput(d, type, raw){
    global_callback(d,type,raw,welive);
}


//设置welive的两个状态
function setTwoStatus(option){
    if(option){
        welive.status = 1; //状态正常, 可以送消息
        welive.autolink = 1; //允许重连
    }else{
        welive.status = 0;
        welive.autolink = 0;
    }
}

//设置为默认头像
function setDefaultAvatar(){
    // 暂时不执行头像设置。
}


function closeSock() {
    welive.autolink = 0;
    clearTimer();
    welive.ws.close();
}

// ajaxUploadImage(1, total_chunks, file.type, "", sending_img_w, sending_img_h);
function getUploadImageJson( file_type, fileData){

    // if(file_temp_data == "") return; //无文件数据返回
    let file_name = "";



    var json_d = {gid: guest.gid, sess: guest.sess, key: SYSKEY, code: SYSCODE, fileType: file_type, fileData: fileData, fileIndex: 1};

    return json_d;

}


export { sendSock, createWebSocket, closeSock,weliveSend,getUploadImageJson };
