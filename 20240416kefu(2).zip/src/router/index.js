import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export const constantRouterMap = [{
    path: '/',
    // component: Home,
    children: [
        // {
        //     path: '/index1',
        //     component: () => import('@/components/view/index1.vue')
        // }, {
        //     path: '/index2',
        //     component: () => import('@/components/view/index2.vue')
        // },
        // {
        //     path: '/index3',
        //     component: () => import('@/components/view/index3.vue')
        // },
    ]
}]

const router = new Router({
    routes: constantRouterMap
})

export default router