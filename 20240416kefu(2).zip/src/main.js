// https://blog.csdn.net/weixin_43304109/article/details/128632430
// 正式环境清除所有console.log
if (process.env.NODE_ENV === 'production') {
  if (window) {
    // window.console.log = function () {};
  }
}

import Vue from 'vue'
import App from './App.vue'
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';

Vue.config.productionTip = false

Vue.use(ElementUI);

import router from './router/index'
import VueRouter from 'vue-router'
Vue.use(VueRouter);

import Viewer from 'v-viewer'
import 'viewerjs/dist/viewer.css'
Vue.use(Viewer)


new Vue({
  router,
  render: h => h(App),
}).$mount('#app')
