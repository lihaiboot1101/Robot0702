<template>
	<div class="service" ref="sercon">
		<img class="bg" :src="toImagePath(parameterData.setting_background)" />

		<div class="logo pointer">
			<img :src="toImagePath(parameterData.setting_head_logo)" />
			<div class="line"></div>
			<div class="t1"> 欢迎使用{{sysName}} </div>

			<el-button v-if="!isLogined" @click="goLogin" class="login-btn" icon="el-icon-user">{{userName}}</el-button>
			<el-button v-else @click="isLogined = false" class="login-btn logout"
				icon="el-icon-switch-button">注销</el-button>
		</div>

		<div class="service-con" :style="w <= 768?'height:'+h+'px;':'' ">
			<div class="left">

				<el-button @click="goLogin" class="login-btn-m" icon="el-icon-user">{{userName}}</el-button>

				<div class="left-t" ref="left-main" :style="`${showbottombtn?'height:calc(100vh - 215px)':''}`">
					<div class="to">
						<img class="avatar" :src="toImagePath(parameterData.setting_head)" />
						<div class="t1">{{ parameterData.setting_welcome }}</div>
					</div>

					<div class="to">
						<img class="avatar" :src="toImagePath(parameterData.setting_head)" />
						<div class="push">
							<img class="log-p" src="@/assets/l-r.png" />
							<div class="push-con">

								<div class="push-con-list">
									<a class="push-con-list-l" accesskey=""
										v-for="( item , index ) in dynamicHotspotList" @click="postAsk(item)">
										{{index+1}} . {{ item }}
										<img src="@/assets/right.png" />
									</a>
								</div>
							</div>
						</div>
					</div>

					<div v-for="(item, index) in askList" :key="index" :style="{'font-size':setSize}"
						:class="[ getAskClass(item.position) , 'know-share']">
						<img v-if="getAskClass(item.position) == 'to'" class="avatar"
							:src="toImagePath(parameterData.setting_head)" />
						<div v-if="item.position == 'left'" class="know-share">
							<div v-show="textloading"> <i class="el-icon-loading"></i> </div>
							<div v-if="item.answer == '请登录后再提问'" data-v-a12db0a8=""
								style="max-height: 120px; overflow: hidden;" @click="goLogin">Hi，<span
									class="color-deep pointer" style="font-weight:bold;">请登录后再提问</span>
							</div>
							<div v-else-if="item.answer_type == '90010'">
								<!--								<div class="t1" v-html="item.answer"></div>-->
								<!--                <v-md-preview :text="item.answer"></v-md-preview>-->
								<vue-markdown :source="asktext" v-if="askList.length==index+1"></vue-markdown>
								<vue-markdown v-else :source="decorateAnswerMarkdown(item.answer,index)"></vue-markdown>
							</div>
							<div v-else-if="item.answer_type == '90011'" @click="show(item.answer)">
								<img :src="item.answer" class="text-right pa-2"
									style="width: 100%;object-fit: contain;">
								</img>
							</div>

							<div v-else-if="item.answer_type == '90012'">
								<div v-for="(answer, index) in item.answer">
									<div class="text-image">
										<div class="t1">{{ answer.title }}</div>
										<div class="t2">{{ answer.context }}</div>
										<img class="iimg" :src="answer.picture" />
										<div class="btn btn1" @click="toOpen(answer.url)">阅读全文</div>
									</div>
								</div>
							</div>

							<div v-if=" (item.recommend_questions && item.recommend_questions.length>0) || item.attachment"
								class="ks-con">
								<div style="display: flex;flex-direction: column;">

									<a :href="toAttachmentPath(attachment)" class="ks-t2"
										v-for="(attachment, attachmentIndex) in item.attachment"
										:key="attachmentIndex">{{ attachmentIndex + 1 }} .
										{{ getAttachmentName(attachment) }}</a>
								</div>
								<div class="c-tip" v-if="item.prompt">{{ item.prompt }}</div>
								<a class="ks-l pointer" v-for="(recommend) in item.recommend_questions || []"
									@click="postAsk(recommend)">○ {{ recommend }}</a>
								<div
									style="padding: 6px 8px;border-radius: 4px;background-color: #fff;border: 1px solid #edf1f7;">
									<i class="el-icon-check" style="color:#10d269"></i>
									知识库匹配结果
								</div>
							</div>

							<!-- <div> -->
							<div v-if="!item.displayFeedback && isShowEvaluate(item,51000)"
								@click="postEvaluate(item,51000)" class="good">
								<img src="@/assets/good.svg" />
							</div>
							<div v-if="!item.displayFeedback && isShowEvaluate(item,51001)"
								@click="postEvaluate(item,51001)" class="ungood">
								<img src="@/assets/ungood.svg" />
							</div>
							<!-- </div> -->

						</div>

						<div v-if="item.position == 'right'" class="t1">
							<div v-if="item.answer_type == '90011'" @click="show(item.answer)">
								<img :src="item.answer" class="text-right pa-2"
									style="max-width: 452px;width:100% ;object-fit: contain;">
								</img>
							</div>
							<div v-else>
								{{ item.answer }}
							</div>

						</div>

						<div v-if="item.position == 'center'">{{ item.answer }}</div>

						<img v-if="getAskClass(item.position) == 'send'" class="avatar"
							:src="toImagePath(parameterData.setting_head_client)" />
					</div>

					<div v-if="joinList.length > 0" class="left-t-c">
						<div v-for="item in joinList" @click="clickInputAsk(item,$event)" class="left-tc-l"
							v-html="item"></div>
					</div>
				</div>
				<div class="left-b" :style="`${showbottombtn?'height:189px':''}`">
					<div style="background-color: #edf1f7;width: 100%;padding: 5px 0;display: none;" class="setSign">
						<div v-if="hsaLive && !showSatisfaction" class="FtureSign" @click="doChatAsk">
							{{isChatting?'退出人工':'转人工'}}</div>
						<div v-if="hsaLive && !showSatisfaction" class="FtureSign" @click="Clear">清屏</div>
					</div>
					<div @click.capture="setFontSize()" class="setfontsize"><img style="width: 16px;height: 16px;"
							src="../assets/search.svg" alt=""></div>
					<div style="display: none;" class="phonesendmsg">
						<div class="phoneinput">
							<el-input class="type-area1"
								style="display: none;width: 500px;border-radius: 0;height: 50px;background-color: #edf1f7;"
								type="textarea" :placeholder="placeholder" @keydown.enter.native="enterAsk"
								@keyup.enter="enterAsk" v-model="inputText" :disabled="showSatisfaction"></el-input>
							<div class="send-btns" style="position: relative;">
								<!-- <div class="btn1" v-if="!showSatisfaction" @click.capture="clickAsk">发送</div> -->
								<div v-if="!showbottombtn && !inputText"
									style="width: 30px;height: 30px;border-radius: 15px;margin-top: -8PX;margin-right: 11PX;">
									<img style="width:24px;" src="../assets/add.svg" alt=""
										@click.capture="setbottombarshow2"></div>
								<div v-else-if="showbottombtn && !inputText"
									style="width: 30px;height: 30px;border-radius: 15px;margin-top: -8PX;margin-right: 11PX;">
									<img style="width:24px;" src="../assets/delete.svg" alt=""
										@click.capture="setbottombarshow"></div>
								<div v-else-if="inputText"
									style="width: 30px;height: 30px;border-radius: 15px;margin-top: -8PX;margin-right: 11PX;">
									<img style="width:24px;" src="../assets/sendicon.svg" alt=""
										@click.capture="clickAsk"></div>
							</div>

						</div>
						<div v-show="showbottombtn"
							style="background-color: #edf1f7;padding: 10px;5px;box-sizing: border-box;">
							<div style="padding: 10px 10px;background-color: #fff;width: 30px;border-radius: 10px;"
								@click="uploadFile">
								<input type="file" ref="fileInput" v-show="false" @change="getFile($event)" />
								<img src="../../src/assets/sendpic.svg" alt="">
							</div>
						</div>
					</div>
					<el-input class="type-area" type="textarea" :rows="3" :placeholder="placeholder"
						@keydown.enter.native="enterAsk" @keyup.enter="enterAsk" v-model="inputText"
						:disabled="showSatisfaction"></el-input>
					<div class="send-btns sendwebmsg">
						<input type="file" ref="fileInput" v-show="false" @change="getFile($event)" />
						<!-- <div class="btn1"   @click="uploadFile">其他</div> -->
						<div class="btn1" @click="clearhistory">清空聊天</div>
						<div class="btn1" v-if="isChatting" @click="uploadFile">图片</div>
						<div class="btn1" v-if="!showSatisfaction" @click="clickAsk">发送</div>
						<div v-if="hsaLive && !showSatisfaction" class="btn2" @click="doChatAsk">
							{{isChatting?'退出人工':'转人工'}}</div>
						<!--              -->
						<div class="btn1" v-if="showSatisfaction && sessionSatisfiedType != '52001'"
							@click="postSatisfaction('52000')">满意</div>
						<div v-if="showSatisfaction && sessionSatisfiedType != '52000' " class="btn2"
							@click="postSatisfaction('52001')">不满意</div>
					</div>
				</div>
			</div>
			<div class="right">
				<div class="right-t">
					<el-carousel class="carousel">
						<el-carousel-item v-for="(slide, i) in slides" :key="i">
							<img class="carousel-img" :src="slide" />
						</el-carousel-item>
					</el-carousel>
				</div>
				<div class="right-m" v-if="quickList && quickList.length > 0">
					<div class="title">
						便捷入口
						<div class="line"></div>
					</div>

					<div class="right-t-c">
						<a class="tc-l" v-for="(item,index) in quickList" @click="toUrl(item.toUrl)">
							<img :src="item.img" />
							<div class="t1">{{ item.name }}</div>
						</a>
					</div>
				</div>
				<div class="right-b">
					<div class="title">
						常见问题
						<div class="line"></div>
					</div>
					<div class="right-b-con">
						<div class="rb-bnr">
							<el-carousel :autoplay="false" indicator-position="none" arrow="always" class="carousel">
								<el-carousel-item class="btn-group"
									v-for="indexL in Math.ceil(classificationList.length/4)">
									<div v-if="classificationList[getClassificationListIndex(indexL,1)]"
										@click="doClickClassification(classificationList[getClassificationListIndex(indexL,1)] , getClassificationListIndex(indexL,1))"
										:class="'gbtn '+ (clickClassificationIndex == getClassificationListIndex(indexL,1)?'gbtn-ac':'') ">
										{{ classificationList[getClassificationListIndex(indexL,1)]?.classification_name }}
									</div>
									<div v-if="classificationList[getClassificationListIndex(indexL,2)]"
										@click="doClickClassification(classificationList[getClassificationListIndex(indexL,2)] , getClassificationListIndex(indexL,2))"
										:class="'gbtn '+ (clickClassificationIndex == getClassificationListIndex(indexL,2)?'gbtn-ac':'') ">
										{{ classificationList[getClassificationListIndex(indexL,2)]?.classification_name }}
									</div>
									<div style="width: 25%;" v-else></div>
									<div v-if="classificationList[getClassificationListIndex(indexL,3)]"
										@click="doClickClassification(classificationList[getClassificationListIndex(indexL,3)] , getClassificationListIndex(indexL,3))"
										:class="'gbtn '+ (clickClassificationIndex == getClassificationListIndex(indexL,3)?'gbtn-ac':'') ">
										{{ classificationList[getClassificationListIndex(indexL,3)]?.classification_name }}
									</div>
									<div style="width: 25%;" v-else></div>
									<div v-if="classificationList[getClassificationListIndex(indexL,4)]"
										@click="doClickClassification(classificationList[getClassificationListIndex(indexL,4)] , getClassificationListIndex(indexL,4))"
										:class="'gbtn '+ (clickClassificationIndex == getClassificationListIndex(indexL,4)?'gbtn-ac':'') ">
										{{ classificationList[getClassificationListIndex(indexL,4)]?.classification_name }}
									</div>
									<div style="width: 25%;" v-else></div>
								</el-carousel-item>

							</el-carousel>
						</div>
						<div class="rb-list">
							<div class="rb-list-l" v-for="(item, i) in commonProblemByClassIdList"
								@click="postAsk(item)">
								<a class="t1 pointer"><span>•</span> {{ item }} </a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="bottom">{{ browserTitle }}</div>

		<el-dialog :visible.sync="dialog">
			<div class="diacon">
				<div class="title">账号登录</div>

				<div class="line"></div>

				<div class="diacon-f">
					<div class="t1">用户名</div>
					<el-input name="name" v-model="account" placeholder="请输入用户名"></el-input>
				</div>

				<div class="diacon-f">
					<div class="t1">密码</div>
					<el-input name="password" type="password" v-model="password" placeholder="请输入密码"></el-input>
				</div>
				<small v-if="loginMessage" style="color: red">*{{ loginMessage }}</small>
				<div class="lore-btn">
					<div @click="isLogined = true;dialog = false" class="btn btn1">登录</div>
					<div @click="dialog = false" class="btn btn2">取消</div>
				</div>

			</div>
		</el-dialog>

	</div>
</template>

<script>
	import jyRquest from "../api/request.js";
	import VueMarkdown from "vue-markdown";
	import {
		sendSock,
		createWebSocket,
		closeSock,
		weliveSend,
		getUploadImageJson,
	} from "../api/socket";
	import {
		request
	} from "@/api/servies";
	const app_key = "gyzndys";
	const app_secret = "GyZndyS";
	const redirect_uri = "https://etalking.zjipc.cn%2F%23%2F";
	const oAuth_uri = "https://ua.zjipc.cn";

	export default {
		name: "service",
		props: {},
		components: {
			"vue-markdown": VueMarkdown,
		},
		data() {
			return {
				isLogined: false,
				issendok: true,
				textloading: false,
				showbottombtn: false,
				setSize: "",
				type: 1,
				type2: 1,
				h: 0,
				w: 0,
				itext: "",
				edia: true,
				loginMessage: "",
				account: "",
				password: "",
				images: [
					"https://picsum.photos/200/200",
					"https://picsum.photos/300/200",
					"https://picsum.photos/250/200",
				],
				asktext: "",
				hsaLogin: false,
				hsaLive: false,
				form: true,
				isLoading: false,
				reveal: true,
				rules: [(v) => v?.length <= 200 || "最大输入200字"],
				visible: true,
				placeholder: "请输入您想咨询的问题，例如：专业、录取、招生计划...",
				inputText: "",
				userName: "请登录",
				parameterData: {},
				classificationList: [],
				clickClassificationIndex: 0,
				dynamicHotspotList: [],
				commonProblemByClassIdList: [],
				askList: [],
				quickList: [],
				joinList: [],
				isChatting: false,
				timer: undefined,
				showSatisfaction: false,
				sessionSatisfiedType: "",
				lastAskData: {},
				base64Data: "",

				dialog: false
			};
		},
		mounted() {
			var that = this;
			this.w = document.body.clientWidth;

			if (this.w <= 768) {
				this.h = document.documentElement.clientHeight; //获取当前屏幕高度
				window.onresize = () => {
					//屏幕高度变化时判断
					return (() => {
						this.h = document.body.clientHeight;
					})();
				};
			}
		},
		computed: {
			browserTitle() {
				return Glod.browserTitle;
			},
			sysName() {
				return Glod.sysName;
			},
			isNotEmptyJoinList() {
				return this.joinList && this.joinList.length > 0;
			},
			breakpointName() {
				let name = this.$vuetify.breakpoint.name;
				console.log("----this.$vuetify.breakpoint.name-------------", name);
				return name;
			},
			isMobile() {
				switch (this.$vuetify.breakpoint.name) {
					case "xs":
						return true;
						// case 'sm': return 400
						// case 'md': return 500
						// case 'lg': return 600
					default:
						return false;
				}
			},
		},
		watch: {
			inputText() {
				if (this.inputText.trim().length > 0) {
					jyRquest
						.postJSON("title/get", {
							content: this.inputText,
						})
						.then((res) => {
							this.joinList = res.records?.slice(0, 4);
							console.log("-----------------", this.joinList);
						});
				} else {
					this.joinList = [];
				}
			},
		},
		created() {
			// 登录存储
			this.userName = localStorage.getItem("userName") || "请登录";

			// vue前端判断当前是PC端还是手机端，跳转不同页面
			// https://blog.csdn.net/qq_41883689/article/details/115146032
			if (this._isMobile()) {
				// window.location.href = "/jqr/";
				// return;
			}

			document.title = Glod.browserTitle;

			const that = this;
			//
			this.hsaLogin = Glod.hsaLogin;
			this.hsaLive = Glod.hsaLive;
			this.quickList = Glod.quickList;
			this.slides = Glod.slides;

			console.log(
				"-------encodeURIComponent-------",
				encodeURIComponent("http://172.16.3.55:1040/xf-kefu/#/")
			);
			console.log("-------encodeURIComponent-------", encodeURIComponent("/#/"));

			jyRquest.postJSON("system/login").then((res) => {
				console.log(res);
			});

			// let {data} = this.useMyFetch('system/parameter');
			// console.log(222222,data,data.data,data.value,data.code);
			// console.log(data.code);

			jyRquest.postJSON("system/parameter").then((res) => {
				console.log("-----setting_welcome----", res);
				this.parameterData = res.data;
				//
				// this.pushAskListLeft({
				// 	answer: this.parameterData.setting_welcome,
				// 	answer_type: '90010',
				// 	displayFeedback: true
				// });
				this.resetTiming();
			});

			jyRquest.postJSON("title/getClassificationList").then((res) => {
				this.classificationList = res.data;
				if (this.classificationList.length > 0) {
					this.postCommonProblemByClassificationId(
						this.classificationList[0].classification_id
					);
				}
			});

			jyRquest.postJSON("qa/record/query", {}).then((res) => {
				console.log("qa/record/query", res);
			});

			jyRquest
				.postJSON("qa/hotKnowledge/query", {
					access_token: "6bc2197cbdc7a334331f464819e7f375",
				})
				.then((res) => {
					this.dynamicHotspotList = res.records.slice(0, 10);
				});

			console.log(this.$data);

			// 获取动态路由参数数据
			console.log(
				"--------------$route--------------",
				this.$route.params,
				this.$route.query
			);
			// 获得单点登录的用户名
			const code = this.$route.query.code;

			if (code) {
				jyRquest
					.post({
						url: "system/proxy",
						headers: {
							"Content-Type": "application/json",
							"X-URL": `${oAuth_uri}/cas/oAuth/accessToken?client_id=${app_key}&client_secret=${app_secret}&grant_type=authorization_code&code=${code}&redirect_uri=${redirect_uri}`,
							"X-METHOD": "POST",
						},
						data: {},
					})
					.then((res) => {
						console.log("=========tr/proxy==============", res);
						let message = JSON.parse(res.message);

						return jyRquest.post({
							url: "system/proxy",
							headers: {
								"Content-Type": "application/json",
								"X-URL": `${oAuth_uri}/cas/oAuth/profile?access_token=${message.accessToken}`,
								"X-METHOD": "GET",
							},
							data: {},
						});
					})
					.then((res) => {
						console.log("=========tr/proxy==============profile====", res);
						let message = JSON.parse(res.message);
						that.userName = message.id;

						for (let i = 0; i < message.attributes.length; i++) {
							const attribute = message.attributes[i];
							if (attribute.realname) {
								that.userName = attribute.realname;
							}
						}
					})
					.catch((reason) => {
						console.log("======catch===reason==============", reason);
					});

				// useFetch(`https://learn.nxnu.edu.cn/cas/oauth2.0/accessToken?client_id=${app_key}&client_secret=${app_secret}&code=${code}&redirect_uri=${redirect_uri}`).json().then(res => {
				// 	console.log('------------accessToken-------------',res.data);
				// 	return useFetch(`https://learn.nxnu.edu.cn/cas/oauth2.0/profile?access_token=${res.data.access_token}`).json();
				// }).then(res => {
				// 	console.log('------------profile-------------',res.data);
				// }).catch(reason => {
				// 	console.log('=========reason==============',reason);
				// });
			}
		},
		methods: {
			Clear() {
				if (!this.issendok) {
					return;
				}
				this.askList = [];
			},
			// 清空历史
			clearhistory() {
				if (!this.issendok) {
					return;
				}
				this.askList = [];
			},
			// 设置底部功能显示
			setbottombarshow() {
				this.showbottombtn = false;
			},
			setbottombarshow2() {
				this.showbottombtn = true;
			},
			// 调整字体大小
			setFontSize() {
				if (this.setSize == "18px") {
					this.setSize = "";
				} else {
					this.setSize = "18px";
				}
			},
			getWeliveApiImg(fileName) {
				return Glod.weliveApi + "/upload/img/" + fileName;
			},
			uploadFile() {
				// const fileInput = this.$refs.fileInput;
				// this.$refs.fileInput.dispatchEvent(new MouseEvent("click"));
				this.$refs.fileInput.click();
				// const file = fileInput.files[0];
				//
				// // 创建一个FormData对象，用于存储文件和其他数据
				// const formData = new FormData();
				// formData.append('file', file);
				// console.log('file------1',file);
			},
			getFile(event) {
				const that = this;
				let file = event.target.files[0];
				var reader = new FileReader();
				reader.onload = function(e) {
					var img = new Image();
					img.src = reader.result;

					img.onload = function() {
						var w = img.width,
							h = img.height;

						if (file.type.toLowerCase() == "image/gif") {
							that.base64Data = e.target.result; //可保持gif动画效果
						} else {
							var canvas = document.createElement("canvas");

							var ctx = canvas.getContext("2d");

							// $(canvas).attr({width: w, height: h});
							canvas.setAttribute("width", w);
							canvas.setAttribute("height", h);
							ctx.drawImage(img, 0, 0, w, h);

							that.base64Data = canvas.toDataURL(file.type, 0.6); //canvas对JPG图片有压缩效果, gif, png
						}

						var result = {
							url: window.URL.createObjectURL(file),
							w: w,
							h: h,
							size: file.size,
							type: file.type,
							base64: that.base64Data.substr(that.base64Data.indexOf(",") + 1),
						};

						// weliveSendImage(result);
						//
						that.pushAskListRight({
							answer: result.url,
							answer_type: "90011",
						});

						let json_d = getUploadImageJson(
							file.type,
							that.base64Data.substr(that.base64Data.indexOf(",") + 1)
						);

						// 获得图片的宽和高。

						jyRquest
							.post({
								url: Glod.weliveApi + "/welive-ajax.php?ajax=1&act=upload_img",
								headers: {
									"Content-Type": "application/x-www-form-urlencoded",
									"X-URL": Glod.weliveApi + `/welive-ajax.php?ajax=1&act=upload_img`,
									"X-METHOD": "POST",
								},
								data: json_d,
							})
							.then((res) => {
								console.log("=======live==tr/welive-ajax==============", res);
								that.showbottombtn = false;
								console.log(this.showbottombtn);
								// 宽 高 必须需要的，否则客服看不到图片。
								weliveSend({
									type: "g_handle",
									operate: "uploadimg",
									filename: res.i,
									width: w,
									height: h,
								}); //w,h指图片的宽,高(像素)
							})
							.catch((reason) => {
								console.log("======catch===reason==============", reason);
							});
					};

					img.onerror = function() {
						console.error("======img.onerror==============");
					};
				};
				reader.readAsDataURL(file);
			},
			decorateAnswerMarkdown2(html, index) {
				html = html.replace(/<br>/g, "\n");
				html = html.replace(/&amp;nbsp;/g, " ");
				console.log("--replace-----", html);
				let arr = html.split("");
				//   console.log(arr, "111");
				this.asktext = "";
				this.textloading = false;
				// if(this.askList.length==index+1){
				arr.forEach((v, index) => {
					setTimeout(() => {
						this.issendok = false;
						if (index + 1 == arr.length) {
							this.issendok = true;
						}
						this.asktext += v;
						this.$nextTick(() => {
							this.$refs["left-main"].scrollTop =
								this.$refs["left-main"].scrollHeight;
						});
					}, 20 * index);
				});
			},
			decorateAnswerMarkdown(html, index) {
				html = html.replace(/<br>/g, "\n");
				html = html.replace(/&amp;nbsp;/g, " ");
				console.log("--replace-----", html);

				return html;
			},
			resetTiming() {
				// 重置定时。
				const that = this;

				if (this.timer) {
					clearTimeout(this.timer);
				}
				if (this.parameterData.setting_timeout_limit && Glod.openSatisfaction) {
					this.timer = setTimeout(() => {
						// 需要定时执行的代码
						that.showSatisfaction = true;
						that.placeholder =
							"对话已结束，您可以开始新的对话 ，或者对我们的满意度进行评价";
						console.log("--------添加内容-------");
					}, this.parameterData.setting_timeout_limit * 60 * 1000);
				}
			},
			getAskClass(position) {
				switch (position) {
					case "left":
						return "to";
					case "right":
						return "send";
					case "center":
						return "center";
					default:
						return "to";
				}
			},
			getClassificationListIndex(indexL, i) {
				// console.log('-----indexL-----', indexL);
				return 4 * (indexL - 1) + (i - 1);
			},
			doClickClassification: function(item, index) {
				this.clickClassificationIndex = index;
				this.postCommonProblemByClassificationId(item.classification_id);
			},
			formatHtml(str) {
				// console.log('---str----', str, typeof str);
				// str = str.replace(/\</g, '&lt;');
				// str = str.replace(/\>/g, '&gt;');
				str = str.replace(/\n/g, "<br/>");
				// <img src="./static/images/face/36.gif" border="0">
				// http://39.105.5.113:1030/xf-ms/views/face
				// `${Glod.API_MS}/views/face/$1.gif`
				// str = str.replace(/\[em_([0-9]*)\]/g, '<img src="static/images/face/$1.gif" border="0" />');
				str = str.replace(
					/\[em_([0-9]*)\]/g,
					`<img src="${Glod.API_MS}/views/face/$1.gif" border="0" />`
				);
				console.log("--replace--afters-str----", str, typeof str);
				return str;
			},
			//判断手机端还是PC端
			_isMobile() {
				let flag = navigator.userAgent.match(
					/(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i
				);
				return flag;
			},
			doClickClassification: function(item, index) {
				this.clickClassificationIndex = index;
				this.postCommonProblemByClassificationId(item.classification_id);
			},
			enterAsk() {
				if (this.inputText.trim().length > 0) {
					this.clickAsk();
				}
			},
			clickAsk() {
				console.log("fasong ");
				// 不输入内容可以发送
				if (this.inputText.trim().length > 0) {
					if (this.isChatting) {
						console.log("人工1");
						if (!this.chatAsk(this.inputText)) {
							// 提问失败。
							console.log("人工");
							this.pushAskListCenter({
								answer: "连接人工失败,转为智能问答",
							});
							this.isChatting = false;
						}
					} else {
						console.log("发送```````````");
						this.postAsk(this.inputText);
					}
				}

				this.inputText = "";
			},
			// 自动滚动
			IsScroll() {
				//   var ele = document.getElementById("test");
				//判断元素是否出现了滚动条
				if (ele.scrollHeight > ele.clientHeight) {
					//设置滚动条到最底部
					ele.scrollTop = ele.scrollHeight;
				}
			},
			clickInputAsk(inputText, event) {
				console.log(inputText, event.target.innerText, event.target.innerHTML);
				console.log(inputText, event.target.outerText, event.target.outerHTML);
				console.log(
					inputText,
					event.currentTarget.innerText,
					event.currentTarget.innerHTML
				);
				console.log(
					inputText,
					event.currentTarget.outerText,
					event.currentTarget.outerHTML
				);
				// this.postAsk(inputText);
				this.postAsk(event.currentTarget.innerText);
				this.inputText = "";
				this.joinList = [];
			},
			doChatAsk() {
				if (this.isChatting) {
					closeSock();
					this.pushAskListCenter({
						answer: "退出人工服务",
					});
				} else {
					// 开始连接客服
					this.pushAskListCenter({
						answer: "正在为您连接客服 ...",
					});
					createWebSocket(this.global_callback);
				}

				this.isChatting = !this.isChatting;
			},
			chatAsk(question) {
				this.pushAskListRight({
					answer: question,
				});
				let msg = {
					type: "msg",
					sendto: "back",
					msg: question,
				};
				return weliveSend(msg);
			},
			postAsk(question) {
				console.log(question, this.showSatisfaction, "question");
				if (!this.issendok) {
					return;
				}
				if (question == false) return;
				if (this.showSatisfaction) return;
				this.textloading = true;
				this.pushAskListRight({
					answer: question,
				});
				this.issendok = false;
				jyRquest
					.post({
						url: "qa/ask",
						headers: {
							"Content-Type": "application/json",
							// https://blog.csdn.net/wzp20092009/article/details/129182055
							"X-TOKEN": encodeURIComponent(this.getToken()),
						},
						data: {
							question,
							access_token: "6bc2197cbdc7a334331f464819e7f375",
							channel_id: "80000",
							user_id: "web",
						},
					})
					.then((dudu) => {
						console.log(dudu, "111");
						const data = dudu;
						if (data.answer_type == "90012") {
							data.answer = JSON.parse(data.answer);
						} else if (data.answer_type == "90010") {
							data.answer = this.formatHtml(data.answer);
						}

						// 过滤垃圾数据   [""]  的返回值内容，导致页面展示有问题。
						if (data.attachment && data.attachment.length > 0) {
							// for (var i = 0; i < data.attachment.length; i++) {
							// 	if(data.attachment[i]){

							// 	}
							// }
							//  https://blog.csdn.net/weixin_46001062/article/details/125973866
							data.attachment = data.attachment.filter((item) => {
								return item;
							});
						}

						this.pushAskListLeft(data);
						this.resetTiming();
						this.lastAskData = data;
						this.$nextTick(() => {
							this.$refs["left-main"].scrollTop =
								this.$refs["left-main"].scrollHeight;
						});
					});
			},
			pushAskListCenter(data) {
				data.position = "center";
				this.askList.push(data);
			},
			pushAskListRight(data) {
				data.position = "right";
				this.askList.push(data);
			},
			pushAskListLeft(data) {
				data.position = "left";
				console.log("----pushAskListLeft-----", data);
				this.decorateAnswerMarkdown2(data.answer);
				this.askList.push(data);
				//    this.$nextTick(() => {
				//         this.$refs["left-main"].scrollTop =
				//           this.$refs["left-main"].scrollHeight;
				//       });
			},
			postEvaluate(data, resolveType) {
				// 没有才执行。

				if (!data.hasOwnProperty("resolveType")) {
					data.resolveType = resolveType;
					this.$forceUpdate();
					jyRquest
						.postJSON("qa/evaluate", {
							resolveType,
							access_token: "6bc2197cbdc7a334331f464819e7f375",
							qaId: data.qa_id,
							sessionId: data.session_id,
							userId: this.getToken(),
						})
						.then((res) => {});
				}
			},
			postSatisfaction(sessionSatisfiedType) {
				// 没有才执行。

				if (!this.sessionSatisfiedType) {
					jyRquest
						.postJSON("qa/satisfaction", {
							sessionSatisfiedType,
							access_token: "6bc2197cbdc7a334331f464819e7f375",
							qaId: this.lastAskData.qa_id,
							sessionId: this.lastAskData.session_id,
							userId: this.getToken(),
						})
						.then((res) => {});
					this.sessionSatisfiedType = sessionSatisfiedType;
				}
			},
			isShowEvaluate(data, resolveType) {
				// console.log('isShowEvaluate===========', data, resolveType);
				if (data.hasOwnProperty("resolveType")) {
					return data.resolveType === resolveType;
				} else {
					// 没有选中
					return true;
				}
			},
			postCommonProblemByClassificationId: function(classificationId) {
				let formdata = new FormData();
				formdata.append("classificationId", classificationId);
				console.log("classificationId===", classificationId);
				jyRquest
					.post({
						method: "POST",
						// body:formdata
						url: `title/getCommonProblemByClassId?classificationId=${classificationId}`,
						headers: {
							"Content-Type": "application/x-www-form-urlencoded",
						},
						// formdata 不可以用。。。
						// body: ''
					})
					.then((res) => {
						console.log("-------res-----------", res);
						this.commonProblemByClassIdList = res.records;
					})
					.catch((err) => {
						console.log("------- err -----------", err);
					});
			},
			getAttachmentName(item) {
				return item.split("/")[1];
			},
			toAttachmentPath(item) {
				return (
					`${Glod.API_MS}/documentation/getFile?documentation_id=` +
					item.split("#")[0]
				);
			},
			toImagePath(name) {
				// return '../assets/logo.svg';  // :src="require('../assets/logo.svg')"
				return `${Glod.imagePath}${name}`;
			},
			goLogin() {
				// 只有是
				this.dialog = true;
				// if (this.userName === "请登录") {
				//   // this.dialog = true;
				//   window.location.href = `${oAuth_uri}/cas/oAuth/authorize?client_id=${app_key}&redirect_uri=${redirect_uri}`;
				// } else {
				//   this.userName = "请登录";
				//   localStorage.removeItem("userName"); // 移除登录。
				// }
			},

			toUrl(url) {
				// window.location.href = url;
				window.open(url, "_blank");
			},
			toOpen(url) {
				window.open(url, "_blank");
			},
			getToken() {
				return this.userName === "请登录" ? "" : this.userName;
			},
			show(url) {
				this.$viewerApi({
					images: [url],
				});
			},
			global_callback(d, type, raw, welive) {
				console.log("xxxxxxxx", d, type, raw, welive);
				console.log("dddddddd", d);
				if (d === false || !type) return; //没有信息及类型返回
				let data = {
					answer: d,
					answer_type: "90010",
				};

				switch (type) {
					case 1: //客服
					case 8: //问候语, 信息不解析(支持html), 不计数
						if (!welive.isRobot && type == 1) {
							welive.unread += 1; //有未读信息
						}
						this.pushAskListLeft(data);
						// d = '<div class="msg l"><div class="a">' + welive_name + ' - ' + welive_duty + '<i>' + getLocalTime() + '</i></div><b></b><div class="b"><div class="i">' + (raw ? d : formatOutput(d)) + '</div></div></div>';
						break;
					case 2: //客人
						// this.pushAskListRight(data);
						// d = '<div class="msg r"><b></b><div class="b"><div class="i">' + (raw ? d : formatOutput(d)) + '</div></div><i>' + getLocalTime() + '<br><s class="un">' + langs.unread + '</s></i></div>';
						break;
					case 3: //正常提示
						// d = '<div class="msg s"><div class="b"><div class="i">' + d + '</div></div></div>';
						this.pushAskListCenter(data);
						break;
					case 4: //错误提示
						// d = '<div class="msg e"><div class="b"><div class="i">' + d + '</div></div></div>';
						this.pushAskListCenter(data);
						break;
				}

				this.$nextTick(() => {
					this.$refs["left-main"].scrollTop =
						this.$refs["left-main"].scrollHeight;
				});

				// historier.append(d);  // 展示内容

				//机器人工作时, 访客发送的信息显示后, 添加机器思考标志

				// if(type == 2 && welive.isRobot){
				//   historier.children(".robot_typing").remove();
				//   d = '<div class="msg l robot_typing"><div class="a">' + welive_name + ' - ' + welive_duty + '<i></i></div><b></b><div class="b"><div class="i"></div></div></div>';
				//   historier.append(d);
				// }

				// scrollBottom(); //滚动到底部
			},
		},
	};
</script>
<style scoped>
	.type-area1 {
		margin-top: -8px;
	}

	/deep/.type-area1 .el-textarea__inner {
		background-color: #edf1f7;
	}
</style>

<style scoped lang="less">
	.phoneinput {
		padding: 0 5px;
		background-color: #fff;
		display: flex;
		height: 75px;
		border: 1px solid #edf1f7;
		align-items: center;
	}
	
	.service .service-con .left .left-t .to .know-share {
		word-wrap: break-word !important;
		word-break: normal !important;
	}

	.setfontsize {
		position: absolute;
		right: 5px;
		top: -30px;
		width: 25px;
		height: 25px;
		background-color: #fff;
		border-radius: 13px;
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.FtureSign {
		padding: 2px 10px;
		background-color: #fff;
		text-align: center;
		border-radius: 10px;
		white-space: nowrap;
		margin-right: 8px;
	}

	//////////////////////////
	.pointer {
		cursor: pointer;
	}

	.color {
		color: #0176ee;
	}

	.vh {}

	.service {
		width: 100vw;
		height: 100%;
		display: flex;
		justify-content: center;
		align-items: center;
		position: relative;
		font-size: 14px;

		.service-con {
			width: 79.25vw;
			height: 76.5%;
			background-color: #fff;
			border-radius: 16px;
			position: relative;
			z-index: 10;
			margin-top: 1%;
			box-sizing: border-box;
			padding: 1.85vh 1.04vw;
			display: flex;
			justify-content: space-between;

			.left {
				width: 56.29vw;
				height: 100%;
				border-radius: 12px;
				overflow: hidden;
				box-sizing: border-box;
				border: 1px solid rgba(237, 241, 247);

				.login-btn-m {
					position: fixed;
					right: 15px;
					top: 15px;
					background-color: #0176ee;
					border-radius: 40px;
					width: 100px;
					height: 40px;
					color: #fff;
					font-size: inherit;
					display: flex;
					align-items: center;
					justify-content: center;
					border: unset;
					z-index: 12;
					display: none;
				}

				.left-t {
					height: 80.64%;
					background-color: rgba(237, 241, 247);
					box-sizing: border-box;
					padding: 1.85vh 1.04vw;
					display: flex;
					flex-wrap: wrap;
					overflow-y: auto;
					align-content: baseline;
					position: relative;

					.to {
						width: 100%;
						display: flex;
						align-items: flex-start;

						.avatar {
							width: 4vh;
							height: 4vh;
							margin-right: 10px;
							margin-top: -0.02vh;
						}

						.t1 {
							font-size: 14px;
							height: auto;
							display: inline-block;
							padding: 1vh 0.5vw;
							background: #fff;
							border-top-left-radius: 14px;
							border-top-right-radius: 4px;
							border-bottom-right-radius: 4px;
							margin-bottom: 2vh;
						}

						.push {
							display: flex;
							width: 27.6vw;
							height: 21.3vh;
							border-bottom-left-radius: 14px;

							margin-bottom: 2vh;
							overflow: hidden;

							.log-p {
								width: 3.646vw;
								height: 21.33vh;
							}

							.push-con {
								width: calc(100% - 5vw);
								background: #fff;
								border-top-right-radius: 4px;
								border-bottom-right-radius: 4px;

								.push-con-bnr {
									height: 4vh;
									border-bottom: 1px solid #ddd;
									display: flex;
									align-items: center;

									.carousel {
										height: 3vh;
										width: 100%;

										.btn-group {
											display: flex;
											justify-content: space-between;

											.gbtn {
												height: 2.6vh;
												padding: 0 0.5vw;
												display: flex;
												align-items: center;
												justify-content: center;
												color: #333;
												text-overflow: ellipsis;
												white-space: nowrap;
												overflow: hidden;
											}

											.gbtn-ac {
												font-weight: 600;
												color: #0176ee;
											}
										}

										.carousel-img {
											width: 100%;
											height: 100%;
										}
									}
								}

								.push-con-list {
									height: 100%;
									box-sizing: border-box;
									padding: 5px 20px;
									overflow-y: auto;

									.push-con-list-l {
										padding: 1vh 0;
										width: 100%;
										display: flex;
										justify-content: space-between;
										cursor: pointer;

										img {
											width: 18px;
											height: 10px;
										}
									}
								}
							}
						}

						.text-image {
							font-size: inherit;
							height: auto;
							display: inline-block;
							padding: 1vh 0.5vw;
							background: #fff;
							border-top-left-radius: 12px;
							border-top-right-radius: 8px;
							border-bottom-right-radius: 8px;
							margin-bottom: 2vh;
							max-width: 80%;

							.t1 {
								margin-bottom: 0.5vh;
								font-size: inherit;
								padding: 0;
							}

							.t2 {
								font-size: 12px;
							}

							.iimg {
								width: 100%;
								margin-top: 0.5vh;
							}

							.btn1 {
								margin-top: 1vh;
								height: 3vh;
								width: 6vw;
								display: flex;
								align-items: center;
								justify-content: center;
								font-size: inherit;
								border-radius: 1vw;
								border: 1px solid #ddd;
								cursor: pointer;
								background-color: #0176ee;
								color: #fff;
							}
						}

						.know-share {
							height: auto;
							display: inline-block;
							padding: 1vh 0.5vw;
							background: #fff;
							border-top-left-radius: 12px;
							border-top-right-radius: 8px;
							border-bottom-right-radius: 8px;
							margin-bottom: 4vh;
							max-width: 80%;
							position: relative;

							.ks-t1 {
								font-size: inherit;
							}

							.ks-con {
								box-sizing: border-box;
								width: 100%;
								//padding: 2vh 2vw 1vh;

								.ks-t2 {
									color: #0176ee;
									margin-bottom: 1vh;
								}

								.c-tip {
									font-size: 13px;
									margin: 3vh 0 1vh;
								}

								.ks-l {
									display: inline-block;
									margin-bottom: 1vh;
									font-size: 12px;
									color: #0176ee;
									width: 100%;
								}
							}

							.t1 {
								margin-bottom: 0;
							}

							.ungood {
								position: absolute;
								right: -5vh;
								width: 4vh;
								height: 4vh;
								background: #fff;
								border-radius: 50%;
								display: flex;
								justify-content: center;
								align-items: center;
								top: 5vh;
								cursor: pointer;

								img {
									width: 65%;
									// transform: rotateX(180deg);
								}
							}

							.good {
								position: absolute;
								right: -5vh;
								width: 4vh;
								height: 4vh;
								background: #fff;
								border-radius: 50%;
								display: flex;
								justify-content: center;
								align-items: center;
								top: 0;
								cursor: pointer;

								img {
									width: 65%;
								}
							}
						}
					}

					.send {
						width: 100%;
						display: flex;
						justify-content: flex-end;
						align-items: flex-start;

						.avatar {
							width: 4vh;
							height: 4vh;
							margin-left: 10px;
							margin-top: -0.02vh;
						}

						.t1 {
							font-size: inherit;
							height: auto;
							display: inline-block;
							padding: 1vh 0.5vw;
							background: #0176ee;
							color: #fff;
							border-top-left-radius: 12px;
							border-top-right-radius: 8px;
							border-bottom-left-radius: 8px;
							margin-bottom: 2vh;
						}
					}

					.send:last-child {
						margin-bottom: 20px;
					}

					.center {
						width: 100%;
						display: flex;
						justify-content: center;

						.t1 {
							font-size: inherit;
							height: auto;
							display: inline-block;
							padding: 1vh 0.5vw;
							background: #0176ee;
							color: #fff;
							border-top-left-radius: 12px;
							border-top-right-radius: 8px;
							border-bottom-left-radius: 8px;
							margin-bottom: 2vh;
						}
					}

					.center:last-child {
						padding-bottom: 20px;
					}

					.left-t-c {
						box-sizing: border-box;
						padding: 12px 24px;
						box-shadow: 0 0 10px rgba(131, 131, 131, 0.4);
						position: sticky;
						bottom: 25px;
						left: 0;
						background: #fff;
						border-radius: 8px;

						.left-tc-l {
							font-size: 14px;
							color: #333;
							cursor: pointer;
						}
					}
				}

				::-webkit-scrollbar {
					width: 4px;
				}

				::-webkit-scrollbar-thumb {
					border-radius: 10px;
					background: #0176ee;
				}

				::-webkit-scrollbar-track {
					border-radius: 0;
					background: #cce4fc;
				}

				.left-b {
					margin-top: -40px;
					height: 18.36%;
					position: relative;

					.type-area {
						border: none;
						font-size: inherit;
					}

					.send-btns {
						width: 100%;
						display: flex;
						margin-top: 1vh;
						justify-content: flex-end;

						.btn1 {
							height: 3.4vh;
							padding: 0 1vw;
							display: flex;
							align-items: center;
							justify-content: center;
							font-size: inherit;
							border-radius: 6px;
							border: 1px solid #ddd;
							cursor: pointer;
							background-color: #0176ee;
							color: #fff;
							margin-right: 1vw;
						}

						.btn2 {
							height: 3.4vh;
							padding: 0 1vw;
							display: flex;
							align-items: center;
							justify-content: center;
							font-size: inherit;
							border-radius: 6px;
							border: 1px solid #0176ee;
							cursor: pointer;
							margin-right: 1vw;
							color: #0176ee;
						}
					}
				}
			}

			.right {
				width: 19.83vw;
				height: 100%;

				.right-t {
					height: 20.83vh;

					.carousel {
						height: 20.83vh;

						.el-carousel__container {
							position: relative;
							height: 20.83vh;
						}

						.carousel-img {
							width: 100%;
							height: 100%;
						}
					}
				}

				.right-m {
					height: 20.18vh;

					.title {
						font-size: 1.2rem;
						font-weight: 600;
						position: relative;
						display: flex;
						justify-content: space-between;
						align-items: center;
						margin-top: 1.8vh;
						text-overflow: ellipsis;
						white-space: nowrap;
						overflow: hidden;
						background: #fff;

						.line {
							width: 75%;
							border-bottom: 1px dashed #cce4fc;
						}
					}

					.right-t-c {
						display: flex;
						align-items: center;
						flex-wrap: wrap;
						justify-content: center;
						height: 18.5vh;

						.tc-l {
							display: block;
							width: 33.33%;
							text-align: center;
							cursor: pointer;

							.t1 {
								font-size: inherit;
							}

							img {
								width: 2.2vw;
							}
						}

						.tc-l:hover .t1 {
							color: #0176ee;
						}
					}
				}

				.right-b {
					margin-top: 2.8vh;
					height: 27vh;

					.title {
						font-size: 1.2rem;
						font-weight: 600;
						position: relative;
						display: flex;
						justify-content: space-between;
						align-items: center;
						margin-top: 1.8vh;
						text-overflow: ellipsis;
						white-space: nowrap;
						overflow: hidden;
						background: #fff;

						.line {
							width: 75%;
							border-bottom: 1px dashed #cce4fc;
						}
					}

					.right-b-con {
						.rb-bnr {
							width: 100%;
							margin-top: 0.5vh;

							.carousel {
								height: 4vh;
								display: flex;
								align-items: center;

								.btn-group {
									display: flex;
									justify-content: space-between;

									.gbtn {
										height: 2.6vh;
										font-size: inherit;
										border-radius: 4px;
										border: 1px solid #ddd;
										cursor: pointer;
										text-overflow: ellipsis;
										white-space: nowrap;
										overflow: hidden;
										width: 23%;
										line-height: 2.6vh;
										text-align: center;
									}

									.gbtn-ac {
										background-color: #0176ee;
										color: #fff;
									}
								}
							}
						}

						.rb-list {
							height: 20vh;
							overflow-y: auto;

							.rb-list-l {
								margin-top: 1.2vh;
								box-sizing: border-box;
								padding: 0 0.5vw;

								.t1 {
									font-size: inherit;
									color: #333;

									span {
										margin-right: 5px;
										color: #999999;
									}
								}
							}
						}

						.rb-list::-webkit-scrollbar {
							width: 4px;
						}

						.rb-list::-webkit-scrollbar-thumb {
							border-radius: 10px;
							background: #0176ee;
						}

						.rb-list::-webkit-scrollbar-track {
							border-radius: 0;
							background: #cce4fc;
						}
					}
				}
			}
		}

		::v-deep .el-dialog {
			border-radius: 16px;
		}

		::v-deep .el-dialog__header {
			padding: 0;
		}

		::v-deep .el-dialog__body {
			padding: 0;
		}

		::v-deep .el-dialog {
			width: 600px;

			.diacon {
				width: 600px;
				height: 385px;
				box-sizing: border-box;
				padding: 40px 90px;

				.title {
					font-size: 28px;
					font-weight: 600;
					letter-spacing: 5px;
					color: #333;
					text-align: center;
				}

				.line {
					height: 1px;
					width: 100%;
					background-color: #0176ee;
					margin-top: 35px;
					margin-bottom: 35px;
				}

				.diacon-f {
					position: relative;
					margin-top: 20px;

					.t1 {
						width: 110px;
						display: flex;
						align-items: center;
						justify-content: center;
						border-right: 1px solid #0176ee;
						font-size: 16px;
						position: absolute;
						left: 0;
						top: 7.5px;
						height: 30px;
						z-index: 2;
					}

					.el-input__inner {
						height: 45px;
						line-height: 45px;
						box-sizing: border-box;
						padding-left: 125px;
					}
				}

				.lore-btn {
					display: flex;
					justify-content: center;
					align-items: center;

					.btn {
						width: 140px;
						height: 45px;
						border-radius: 6px;
						display: flex;
						justify-content: center;
						align-items: center;
						font-size: 14px;
						margin: 40px 30px;
					}

					.btn1 {
						background-color: #0176ee;
						color: #fff;
					}

					.btn2 {
						border: 1px solid #0176ee;
						color: #0176ee;
						box-sizing: border-box;
					}
				}
			}
		}

		.bottom {
			position: fixed;
			bottom: 4%;
			text-align: center;
			font-size: inherit;
			color: #fff;
		}

		::v-deep .right-t .el-carousel__container {
			height: 20.83vh;
		}

		::v-deep .right-b .el-carousel__container,
		::v-deep .push-con .el-carousel__container {
			height: 3vh;
			width: 86%;
			margin-left: 7%;
		}

		::v-deep .right-b .el-carousel__arrow,
		::v-deep .push-con .el-carousel__arrow {
			background-color: unset;
			color: #c0c0c0;
			height: 2.59vh;
			width: 1.46vw;
		}

		::v-deep .right-b .el-carousel__arrow--left,
		::v-deep .push-con .el-carousel__arrow--left {
			left: -1.5vw;
			font-size: 1rem;
		}

		::v-deep .right-b .el-carousel__arrow--right,
		::v-deep .push-con .el-carousel__arrow--right {
			right: -1.5vw;
			font-size: 1rem;
		}

		::v-deep .el-textarea__inner {
			border: 0px solid #dcdfe6;
			height: 8vh;
		}

		.bg {
			position: absolute;
			left: 0;
			bottom: 0;
			width: 100%;
			height: 100%;
		}

		.logo {
			width: 79.25%;
			height: 7.4%;
			display: flex;
			align-items: center;
			position: absolute;
			top: 3.7%;
			left: 10.375%;

			.login-btn {
				position: absolute;
				right: 0;
				background-color: rgba(255, 255, 255, 0.4);
				border-radius: 6px;
				width: 5.2vw;
				height: 3.8vh;
				color: #fff;
				font-size: inherit;
				display: flex;
				align-items: center;
				justify-content: center;
				border: unset;
			}

			.logout {
				background-color: rgba(230, 162, 60, 0.4);
			}

			img {
				height: 100%;
			}

			.line {
				height: 100%;
				width: 3px;
				background: linear-gradient(to bottom,
						rgba(255, 255, 255, 0) 0,
						rgba(255, 255, 255, 1) 50%,
						rgba(255, 255, 255, 0) 100%);
				margin: 0 2%;
			}

			.t1 {
				font-size: 1.8rem;
				color: #fff;
			}
		}
	}

	/* 屏幕分辨率放大为 150 */
	@media (-webkit-min-device-pixel-ratio: 1.1) {
		.service {
			font-size: 0.8rem;
		}

		.service .service-con .right .right-m .title {
			font-size: 1.1rem;
		}

		.service .service-con .right .right-b .title {
			font-size: 1.1rem;
		}

		.service .logo .t1 {
			font-size: 1.7rem;
		}
	}

	/* 屏幕分辨率放大为 150 */
	@media (-webkit-min-device-pixel-ratio: 1.25) {
		.service {
			font-size: 0.7rem;
		}

		.service .service-con .right .right-m .title {
			font-size: 1rem;
		}

		.service .service-con .right .right-b .title {
			font-size: 1rem;
		}

		.service .logo .t1 {
			font-size: 1.6rem;
		}
	}

	/* 屏幕分辨率放大为 150 */
	@media (-webkit-min-device-pixel-ratio: 1.5) {
		.service {
			font-size: 12px !important;
		}

		.service .service-con .right .right-m .title {
			font-size: 0.9rem;
		}

		.service .service-con .right .right-b .title {
			font-size: 0.9rem;
		}

		.service .logo .t1 {
			font-size: 1.5rem;
		}
	}

	// 手机端
	@media (max-width: 768px) {
		.setSign {
			display: flex !important;
		}

		.sendwebmsg {
			display: none !important;
		}

		.phonesendmsg {
			display: block !important;
		}

		.logo {
			display: none !important;
		}

		.bottom {
			display: none;
		}

		.service {
			font-size: 14px;

			.service-con {
				width: 100vw;
				height: 100%;
				padding: 15px;
				margin-top: 0;
				border-radius: 0;

				.left {
					width: 100%;
					position: relative;

					.login-btn-m {
						display: block;
					}

					.left-t {
						height: calc(100% - 75px);

						.t1 {
							max-width: 80%;
							padding: 10px !important;
						}

						.push {
							width: 98% !important;
							height: 154px !important;
							font-size: 12px !important;
						}

						.left-t-c {
							box-sizing: border-box;
							padding: 12px 24px;
							box-shadow: 0 0 10px rgba(131, 131, 131, 0.4);
							position: sticky;
							bottom: 50px;
							left: 10px;
							background: #fff;
							border-radius: 8px;
						}

						.to {
							.avatar {
								width: 36px;
								height: 36px;
								margin-left: 10px;
								margin-top: -2px;
							}

							.know-share {
								.ungood {
									margin-left: 10px;
									float: left;
									left: 0px;
									bottom: 0;
									width: 30px;
									height: 30px;
									position: relative;
									top: 0px;

									img {
										width: 76%;
									}
								}

								.good {
									float: left;
									position: relative;
									left: 0;
									bottom: 0;
									width: 30px;
									height: 30px;

									img {
										width: 76%;
										// transform: rotateX(180deg);
									}
								}
							}
						}

						.to:last-child {
							margin-bottom: 20px;
						}

						.send {
							.avatar {
								width: 36px;
								height: 36px;
								margin-right: 10px;
								margin-top: -2px;
							}
						}
					}

					.left-b {
						height: 109px;
						position: fixed;
						bottom: 15px;
						width: calc(100% - 30px);
						background: #fff;
						padding-bottom: 0px;

						.type-area {
							display: none !important;
						}

						.type-area1 {
							display: block !important;
							border: none;
							font-size: inherit;
						}

						.send-btns {
							position: absolute;
							top: 7px;
							right: 0;
							margin-top: 0;
							width: 105px;

							.btn1 {
								margin-right: 10px !important;
								box-sizing: border-box;
								padding-right: 96px;
							}

							.btn2 {
								border: 1px solid #0176ee;
								color: #0176ee;
								box-sizing: border-box;
							}
						}
					}
				}

				.right {
					display: none;
				}
			}

			.service-con .left .left-t .to .push .log-p {
				width: 40px;
				height: 154px !important;
			}

			.right-b .el-carousel__arrow--left,
			.service .push-con .el-carousel__arrow--left {
				left: -17px;
				font-size: 1rem;
			}

			.service-con .left .left-t .to .push .push-con .push-con-list {
				height: 94%;
				margin-top: 3%;
			}

			.service-con .left .left-t .to .push .push-con .push-con-bnr {
				height: 27px;
				border-bottom: 1px solid #ddd;
			}

			.service-con .left .left-t .to .push .push-con .push-con-list .push-con-list-l {
				padding: 5px 0;
				width: 100%;
				display: flex;
				justify-content: space-between;
				cursor: pointer;
			}

			.service-con .left .left-b .send-btns .btn1 {
				height: 36px;
				padding: 0 25px;
				border-radius: 6px;
				border: 1px solid #ddd;
				margin-right: 20px;
				cursor: pointer;
			}

			.service-con .left .left-b .send-btns .btn2 {
				height: 36px;
				padding: 0 25px;
				border-radius: 6px;
				border: 1px solid #ddd;
				cursor: pointer;
				margin-right: 1vw;
			}

			::v-deep .el-input__inner {
				height: 50px !important;
				border-bottom-left-radius: 12px;
				border-bottom-right-radius: 12px;
			}

			::v-deep .right-b .el-carousel__arrow--left,
			::v-deep .push-con .el-carousel__arrow--left {
				left: -16px;
				font-size: 16px;
			}

			::v-deep .right-b .el-carousel__arrow--right,
			::v-deep .push-con .el-carousel__arrow--right {
				right: -5px;
				font-size: 16px;
			}

			::v-deep .el-dialog {
				width: 600px;

				.diacon {
					width: 600px;
					height: 385px;
					box-sizing: border-box;
					padding: 40px 90px;

					.title {
						font-size: 28px;
						font-weight: 600;
						letter-spacing: 5px;
						color: #333;
						text-align: center;
					}

					.line {
						height: 1px;
						width: 100%;
						background-color: #8e188a;
						margin-top: 35px;
						margin-bottom: 35px;
					}

					.diacon-f {
						position: relative;
						margin-top: 20px;

						.t1 {
							width: 110px;
							display: flex;
							align-items: center;
							justify-content: center;
							border-right: 1px solid #8e188a;
							font-size: 16px;
							position: absolute;
							left: 0;
							top: 7.5px;
							height: 30px;
							z-index: 2;
						}

						.el-input__inner {
							height: 45px;
							line-height: 45px;
							box-sizing: border-box;
							padding-left: 125px;
						}
					}

					.lore-btn {
						display: flex;
						justify-content: center;
						align-items: center;

						.btn {
							width: 140px;
							height: 45px;
							border-radius: 6px;
							display: flex;
							justify-content: center;
							align-items: center;
							font-size: 14px;
							margin: 40px 30px;
						}

						.btn1 {
							background-color: #8e188a;
							color: #fff;
						}

						.btn2 {
							border: 1px solid #8e188a;
							color: #8e188a;
							box-sizing: border-box;
						}
					}

				}
			}


			.service-con .left .left-t .to .text-image {
				max-width: 98%;
			}

			.service-con .left .left-t .to .text-image {
				padding: 10px;
			}

			.service-con .left .left-t .to .text-image .t1 {
				padding: 0 !important;
				margin-bottom: 10px;
			}

			.service-con .left .left-t .to .text-image .t2 {
				margin-bottom: 10px;
			}

			.service-con .left .left-t .to .text-image .btn1 {
				height: 36px;
				line-height: 36px;
				width: 80px;
			}

			.service-con .left .left-t .to .know-share {
				padding: 10px;
				max-width: 98%;
				width: calc(100% - 80px);
				word-wrap: break-word !important;
				word-break: normal !important;
			}
			
		}

	}

	// ::v-deep .el-textarea textarea::placeholder {
	//   font-size: 1.1rem;
	// }
</style>