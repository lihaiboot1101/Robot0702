<template>
  <div id="app">
    <service />
  </div>
</template>

<script>
import service from './components/service.vue'

export default {
  name: 'App',
  components: {
    service
  }
}
</script>

<style>
body,html {
	margin:0 ;
	padding: 0;
	width: 100%;
	height: 100%;
}
#app {
	width: 100%;
	height: 100%;
}
</style>
