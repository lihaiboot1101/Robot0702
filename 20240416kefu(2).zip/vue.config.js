const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
    transpileDependencies: true,
    publicPath : "/xf-kefu/" ,    //浏览器url地址前缀
    // outputDir : "xf-kefu" ,  //打包文件夹名
    productionSourceMap:false, // 如何取消生成.map文件，防止反编译。
    lintOnSave: false,
    devServer: {
        proxy: {
            '/xf-engine': {
                target: 'http://39.105.5.113:1040',
                changeOrigin: true,
                //pathRewrite: {
                // '^/xf-engine': '/xf-engine'
                //},
                // ws:true, //用于支持webpack
                // changeOrigin:true //用于控制请求头中host值
            },
            '/demo': {
                target: 'http://localhost:5001',
                pathRewrite: {
                    '^/demo': ''
                },
                // ws:true, //用于支持webpack
                // changeOrigin:true //用于控制请求头中host值
            }
        }
    },
})
